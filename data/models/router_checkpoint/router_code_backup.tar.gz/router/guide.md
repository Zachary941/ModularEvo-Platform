# 🛠️ 开发指南：基于数据集分布的动态模型合并 Router (Context-Aware Task Vector Routing)

## 1. 项目目标与使用场景

### 1.1 核心目标

构建一个动态路由系统（Router），它能分析客户提供的**无标注**混合数据集（包含不同任务，如法律、数学、代码、语言识别），同时完成两件事：

1. **自动识别**每条数据属于哪个任务（任务分类），以选择正确的分类头。
2. **自动计算**最佳的"任务向量"合并系数 $\alpha$，用于合并模型主体。

### 1.2 两阶段工作流

**阶段一：训练 Router（离线，开发者完成）**

* 使用**带标注的**混合数据集（已知每条样本属于哪个任务）训练 Router。
* 训练时采用 Batch 级路由，通过端到端梯度下降优化 Router 参数。
* 训练损失：合并模型在混合 Batch 上的总 Cross-Entropy Loss + 任务分类辅助 Loss。
* 验证指标：各任务的分类 **ACC（准确率）**。

**阶段二：推理部署（在线，面向客户）**

* 客户提交一个**无标注的**混合数据集。
* Router 对整个数据集进行分析，输出：
    * **一组全局合并权重** $\alpha = [\alpha_{code}, \alpha_{langid}, \alpha_{law}, \alpha_{math}]$（Dataset 级别，只有一组）。
    * **每条样本的任务归属**（用于选择对应的分类头）。
* 用 $\alpha$ 和预存的 Task Vectors 合并出一个固定的模型 Backbone。
* 将合并后的 Backbone + 所有分类头 + 样本任务归属 打包交付给客户。

### 1.3 核心公式

$$\text{Merged\_Model} = \theta_{base} + \sum_{i} \alpha_i \cdot \tau_i$$

其中 $\tau_i = \theta_{finetuned_i} - \theta_{base}$ 为第 $i$ 个任务的任务向量，$\alpha_i \in [0, 1]$ 为独立的合并权重（各 $\alpha_i$ 之间互不约束，和不一定为 1）。

### 1.4 举例说明

客户提交数据集包含 5 条法律条文 + 10 道数学题 + 3 条代码 + 0 条欧洲语言文本。Router 分析后输出：

* 合并权重：$\alpha = [0.2, 0.0, 0.3, 0.8]$（代码、语言识别、法律、数学）
* 样本任务归属：前 5 条 → law（使用 Head C），中间 10 条 → math（使用 Head D），后 3 条 → code（使用 Head A）
* 合并模型配上对应的分类头后，在该数据集上应取得较高的分类准确率。

## 2. 预备资源与环境

### 2.1 模型资源

* **基座模型：** `GPTNeoForCausalLM`（HuggingFace `transformers`，**注意：使用带 LM Head 的版本**，并配合 `output_hidden_states=True` 取最后一层隐状态用于分类）。
* **基座模型路径：** `data/gpt-neo-125m/`（GPT-Neo 125M）
* **微调模型：** 四个从同一基座通过 **mask-based 微调**（模块化稀疏微调，mask_rate=0.25）得到的分类模型，每个模型的 Backbone 和分类头封装在同一个 `GPTNeoWithClassificationHead` 类中，保存为单个 `pytorch_model.bin`：
    * Model A (代码语言分类, 1006 类) — `fintune/save_model_with_mask_0.25/code/lr5e-05_bs8_e4_p6_all/best_model/pytorch_model.bin`
    * Model B (欧洲语言识别, 6 类) — `fintune/save_model_with_mask_0.25/langid/20250309_142219_lr5e-05_bs16_e4_p6/best_model/pytorch_model.bin`
    * Model C (法律分类/SCOTUS, 13 类) — `fintune/save_model_with_mask_0.25/law/scotus/lr5e-05_bs4_e4/result/pytorch_model.bin`
    * Model D (数学QA分类, 25 类) — `fintune/save_model_with_mask_0.25/mathqa/lr5e-05_bs4_e2/best_model/pytorch_model.bin`

### 2.2 模型的大概结构

每个微调模型是一个**完整的端到端模型**，将 `GPTNeoForCausalLM` 作为 backbone，并在其上添加分类头。Backbone 和分类头**不是**独立保存的，而是封装在同一个类中，通过 `torch.save(model.state_dict(), path)` 保存为单个文件。

```python
import torch
import torch.nn as nn
from transformers import GPTNeoForCausalLM

class GPTNeoWithClassificationHead(nn.Module):
    def __init__(self, base_model_name, num_classes):
        super().__init__()
        # 注意：使用 GPTNeoForCausalLM（带 LM Head），不是 GPTNeoModel
        self.base_model = GPTNeoForCausalLM.from_pretrained(base_model_name)
        self.hidden_size = self.base_model.config.hidden_size  # 768 for GPT-Neo 125M
        self.num_classes = num_classes
        self.base_model.config.output_hidden_states = True
        self.classification_head = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.LayerNorm(self.hidden_size),
            nn.ReLU(),
            nn.Dropout(0.2), 
            nn.Linear(self.hidden_size, self.hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(self.hidden_size // 2, num_classes)
        )

    def forward(self, input_ids, attention_mask=None, labels=None):
        outputs = self.base_model(
            input_ids=input_ids, 
            attention_mask=attention_mask
        )
        
        # 取最后一层隐状态（通过 output_hidden_states=True 获取）
        last_hidden_state = outputs.hidden_states[-1]
        sentence_representation = torch.mean(last_hidden_state, dim=1)  
        layer_norm = nn.LayerNorm(self.hidden_size).to(last_hidden_state.device)
        sentence_representation = layer_norm(sentence_representation)
        
        logits = self.classification_head(sentence_representation)
        
        loss = None
        if labels is not None:
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits, labels)
            
        return {'loss': loss, 'logits': logits} if loss is not None else {'logits': logits}
```

**重要说明：**

* 各任务的 `num_classes` 不同：code=707, langid=6, law=13, mathqa=25。
* `hidden_size` = 768（GPT-Neo 125M）。
* 保存的 state_dict 中，参数名前缀为 `base_model.*`（Backbone 部分）和 `classification_head.*`（分类头部分）。后续提取 Task Vector 和分类头权重时，需要按前缀区分。
* 微调使用了 **mask-based 稀疏微调**（mask_rate=0.25），即只有被模块化 mask 标记的约 25% 的参数会在微调中更新，其余参数保持与基座模型一致。这意味着 Task Vector 天然是稀疏的。

### 2.3 工具库

* `PyTorch`（必须支持 `torch.nn.utils.stateless.functional_call`）
* `Transformers`（HuggingFace）

### 2.4 建议的项目文件结构

```
Router/
├── guide.md              # 本开发指南
├── config.py             # 全局配置（模型路径、任务定义、hidden_size、num_classes 等）
├── task_vectors.py       # 步骤1：计算和加载 Task Vectors 与分类头
├── router.py             # 步骤2：Router 网络定义
├── merge.py              # 步骤3：函数式动态合并逻辑
├── data.py               # 步骤4：混合数据集构造与 DataLoader
├── train.py              # 步骤5：训练循环
├── evaluate.py           # 步骤6：评估阶段（合并效果 + 任务识别性能）
├── infer.py              # 步骤7：推理与部署（面向客户）
└── utils.py              # 工具函数（日志、保存/加载等）
```

## 3. 核心模块实现步骤

### 步骤 1：预计算与加载 Task Vectors (任务向量)

**说明：** 为了节省显存和计算，不要在训练循环中加载整个微调模型。只预计算差值并保存。

**逻辑：**

1. 加载基座模型：实例化 `GPTNeoWithClassificationHead(base_model_path, num_classes=任意)`，提取其中 `base_model`（即 `GPTNeoForCausalLM`）的权重作为 $\theta_{base}$。
2. 依次加载每个微调模型的完整 state_dict（`torch.load(path)`），从中筛选出 **`base_model.*` 前缀**的参数作为 $\theta_{finetuned_i}$。
3. 计算任务向量 $\tau_i = \theta_{finetuned_i} - \theta_{base}$（只对 `base_model.*` 部分做差，不含 `classification_head.*`）。
4. 从同一 state_dict 中筛选出 **`classification_head.*` 前缀**的参数，构建对应的分类头并加载权重。
5. 释放原始 state_dict 以节省显存。

**⚠️ 关键注意事项：** 由于微调使用了 mask-based 稀疏微调（mask_rate=0.25），Task Vector 天然是稀疏的——大部分参数的差值为零。这是正常的，不需要额外处理。

**存储格式与加载方式：**

```python
import torch
import torch.nn as nn
from transformers import GPTNeoForCausalLM

# ===== 配置 =====
BASE_MODEL_PATH = 'data/gpt-neo-125m/'

TASK_CONFIGS = {
    'code':   {'num_classes': 1006, 'model_path': 'fintune/save_model_with_mask_0.25/code/lr5e-05_bs8_e4_p6_all/best_model/pytorch_model.bin'},
    'langid': {'num_classes': 6,   'model_path': 'fintune/save_model_with_mask_0.25/langid/20250309_142219_lr5e-05_bs16_e4_p6/best_model/pytorch_model.bin'},
    'law':    {'num_classes': 13,  'model_path': 'fintune/save_model_with_mask_0.25/law/scotus/lr5e-05_bs4_e4/result/pytorch_model.bin'},
    'math':   {'num_classes': 25,  'model_path': 'fintune/save_model_with_mask_0.25/mathqa/lr5e-05_bs4_e2/best_model/pytorch_model.bin'},
}

# ===== 1. 加载基座模型的 Backbone 权重 =====
base_model = GPTNeoForCausalLM.from_pretrained(BASE_MODEL_PATH)
base_model.config.output_hidden_states = True
base_params = dict(base_model.named_parameters())
# 冻结基座模型
for p in base_params.values():
    p.requires_grad = False

# ===== 2. 提取 Task Vectors 和分类头 =====
task_vectors = {}  # Dict[str, Dict[str, Tensor]]
heads = {}         # Dict[str, nn.Sequential]

for task_name, config in TASK_CONFIGS.items():
    # 加载完整的微调模型 state_dict
    state_dict = torch.load(config['model_path'], map_location='cpu')
    
    # 2a. 提取 Backbone 部分并计算 Task Vector
    # 微调模型的 state_dict key 格式: "base_model.transformer.h.0.attn.attention.k_proj.weight"
    # 基座模型的 named_parameters key 格式: "transformer.h.0.attn.attention.k_proj.weight"
    tau = {}
    for key, base_param in base_params.items():
        finetuned_key = f"base_model.{key}"  # 添加 "base_model." 前缀
        if finetuned_key in state_dict:
            tau[key] = (state_dict[finetuned_key] - base_param.data).detach()
    task_vectors[task_name] = tau
    
    # 2b. 提取分类头权重
    head = nn.Sequential(
        nn.Linear(768, 768),       # hidden_size = 768
        nn.LayerNorm(768),
        nn.ReLU(),
        nn.Dropout(0.2),
        nn.Linear(768, 384),       # hidden_size // 2 = 384
        nn.ReLU(),
        nn.Dropout(0.1),
        nn.Linear(384, config['num_classes'])
    )
    head_state = {k.replace('classification_head.', ''): v 
                  for k, v in state_dict.items() if k.startswith('classification_head.')}
    head.load_state_dict(head_state)
    
    # 冻结分类头
    for p in head.parameters():
        p.requires_grad = False
    heads[task_name] = head
    
    # 释放 state_dict
    del state_dict

# task_vectors: Dict[str, Dict[str, Tensor]]
# task_vectors['code'][param_name] 对应 code 任务向量的各层参数差值
# task_vectors['langid'][...], task_vectors['law'][...], task_vectors['math'][...]

# heads: Dict[str, nn.Sequential]
# heads['code'], heads['langid'], heads['law'], heads['math']
# 所有分类头已冻结: requires_grad=False
```

**关键：**
* 确保 task_vectors 中的 key（参数名）与 `GPTNeoForCausalLM` 的 `named_parameters()` 完全一致（不含 `base_model.` 前缀）。
* 微调模型的 state_dict 中参数名带有 `base_model.` 前缀（因为 `GPTNeoForCausalLM` 被封装在 `GPTNeoWithClassificationHead.base_model` 中），加载时需要做前缀映射。

### 步骤 2：构建 Router 网络（双头架构）

**说明：** Router 是一个轻量级网络，具有**两个输出头**，共享同一个 Encoder：

1. **Merge Head（合并权重预测）**：分析整个 Batch/数据集的分布，输出合并权重 $\alpha$。
2. **Task Classifier Head（任务识别）**：对每条样本预测它属于哪个任务，用于选择分类头。

**架构设计：**

```python
import torch
import torch.nn as nn

class Router(nn.Module):
    def __init__(self, embedding_layer, hidden_size, num_tasks):
        """
        Args:
            embedding_layer: GPTNeoForCausalLM 的 Embedding 层（冻结）
                             即 base_model.transformer.wte
            hidden_size: Embedding 维度（768 for GPT-Neo 125M）
            num_tasks: 任务数量（4：code, langid, law, math）
        """
        super().__init__()
        # 共享 Encoder：使用冻结的 GPT-Neo Embedding
        self.embedding = embedding_layer  # 冻结，不训练

        # Head 1: Merge Weight Predictor（Dataset 级别）
        # 输入：整个 Batch 的 Pooled Embedding
        # 输出：每个任务的独立合并权重 α_i ∈ (0, 1)
        self.merge_head = nn.Sequential(
            nn.Linear(hidden_size, 64),
            nn.ReLU(),
            nn.Linear(64, num_tasks),
            nn.Sigmoid()  # 各任务权重独立，不互相约束
        )

        # Head 2: Task Classifier（Sample 级别）
        # 输入：每条样本的 Embedding
        # 输出：该样本属于各任务的概率分布
        self.task_classifier = nn.Sequential(
            nn.Linear(hidden_size, 64),
            nn.ReLU(),
            nn.Linear(64, num_tasks)
            # 注意：不加 Softmax，交给 CrossEntropyLoss 内部处理
        )

    def forward(self, input_ids, attention_mask):
        # 1. 共享 Embedding（冻结，不回传梯度到 Embedding）
        with torch.no_grad():
            embeddings = self.embedding(input_ids)  # [Batch, Seq, Hidden]

        # 2. Per-sample Mean Pooling（考虑 attention_mask）
        mask = attention_mask.unsqueeze(-1).float()          # [Batch, Seq, 1]
        sample_embeds = (embeddings * mask).sum(dim=1) / mask.sum(dim=1)  # [Batch, Hidden]

        # 3. Merge Head：Global Mean Pooling → 一组 α
        batch_embed = sample_embeds.mean(dim=0, keepdim=True)  # [1, Hidden]
        alphas = self.merge_head(batch_embed).squeeze(0)        # [num_tasks]

        # 4. Task Classifier：Per-sample → 每条样本的任务 logits
        task_logits = self.task_classifier(sample_embeds)       # [Batch, num_tasks]

        return alphas, task_logits

# 初始化示例：
# embedding_layer = base_model.transformer.wte  # GPTNeoForCausalLM 的 word embedding
# router = Router(embedding_layer, hidden_size=768, num_tasks=4)
```

**关键设计决策：**

* **Sigmoid 而非 Softmax 用于合并权重**：各任务向量的合并权重独立，$\alpha_i \in (0, 1)$，和不一定为 1。例如 $[0.2, 0.0, 0.3, 0.8]$ 是合法的。Softmax 会强制零和竞争，不符合实际需求。
* **Task Classifier 使用 CE Loss**：每条样本属于且仅属于一个任务，这是标准分类问题，不在输出层加 Softmax，交给 `CrossEntropyLoss` 内部处理。
* **Embedding 层冻结**：Router 只训练 `merge_head` 和 `task_classifier` 的参数。
* **Embedding 来源**：使用 `GPTNeoForCausalLM` 的 `transformer.wte`（Word Token Embedding），不是整个 Transformer。

### 步骤 3：实现"函数式"动态合并 (关键技术点)

**说明：** 这是最难的部分。不能使用 `model.load_state_dict`，因为它是不可导的且速度极慢。必须使用 PyTorch 的 `functional_call`，让梯度能从合并模型的输出一路回传到 Router 的 $\alpha$ 输出。

**⚠️ 注意参数名映射：** `functional_call` 接收的参数名必须与 `GPTNeoForCausalLM` 的 `named_parameters()` 一致（不含 `base_model.` 前缀）。Step 1 中已经确保 task_vectors 的 key 使用了正确的格式。

* **关键代码逻辑：**

```python
import torch
from torch.nn.utils.stateless import functional_call

# task_names 定义了各任务对应到 alphas 的索引
TASK_NAMES = ['code', 'langid', 'law', 'math']  # 与 Router num_tasks=4 对应

def compute_merged_params(base_params, task_vectors, alphas, task_names=TASK_NAMES):
    """
    计算合并后的模型参数（保留计算图，可微分）。

    Args:
        base_params: Dict[str, Tensor] — GPTNeoForCausalLM 的参数（不含 base_model. 前缀）
        task_vectors: Dict[str, Dict[str, Tensor]] — 各任务向量，key 为任务名
        alphas: Tensor [num_tasks] — Router 输出的合并权重（带梯度）
        task_names: List[str] — 任务名列表，与 alphas 索引对应

    Returns:
        merged_params: Dict[str, Tensor] — 合并后的参数
    """
    merged_params = {}
    for name, param in base_params.items():
        delta = sum(
            alphas[i] * task_vectors[task_name][name]
            for i, task_name in enumerate(task_names)
            if name in task_vectors[task_name]
        )
        merged_params[name] = param + delta
    return merged_params

# 在 Forward 时使用 functional_call 调用 GPTNeoForCausalLM：
# output = functional_call(base_model, merged_params,
#              args=(), kwargs={'input_ids': input_ids, 'attention_mask': attention_mask})
# 由于 base_model.config.output_hidden_states = True：
# hidden_states = output.hidden_states[-1]  # [Batch, Seq, Hidden] — 最后一层隐状态
```

**⚠️ 注意：** `alphas` 必须是带梯度的 Tensor（来自 Router 的输出），这样 `total_loss.backward()` 才能将梯度回传给 Router。

**隐状态后处理：** 从 `functional_call` 获取 `hidden_states[-1]` 后，需要做与微调模型相同的后处理才能送入分类头：

```python
# 与 GPTNeoWithClassificationHead.forward 中一致的后处理
last_hidden_state = output.hidden_states[-1]                    # [Batch, Seq, 768]
sentence_representation = torch.mean(last_hidden_state, dim=1)  # [Batch, 768]
layer_norm = nn.LayerNorm(768).to(last_hidden_state.device)
sentence_representation = layer_norm(sentence_representation)   # [Batch, 768]
# 然后送入对应的 heads[task_name]
logits = heads[task_name](sentence_representation)              # [Batch, num_classes]
```

### 步骤 4：构建训练数据集与加载器

**说明：** 训练 Router 需要**带任务标注的**混合数据集。训练时 `task_ids` 有两个用途：

1. 作为 Task Classifier Head 的监督信号。
2. 用于将 Batch 拆分到对应的分类头计算 Loss。

#### 4.1 训练数据来源

各任务的原始数据集及其字段格式如下：

| 任务 | 数据源 | 文本字段 | 标签字段 | 标签类型 | num_classes |
|------|--------|---------|----------|---------|-------------|
| code | `fintune/data/code/` (Parquet) | `code` | `language_name` | 字符串→映射 | 1006 |
| langid | `fintune/data/langid/` (CSV/TXT) | `sentence` | `language` | 字符串→映射 (2字符语言码) | 6 |
| law | `fintune/data/lex_glue/scotus/` (Parquet) | `text` | `label` | 数值（0-12） | 13 |
| math | `fintune/data/mathqa/` (Parquet) | `question` | `topic` | 字符串→映射 | 25 |

**注意：** 各任务使用不同的文本字段名和标签字段名，在构建统一的混合 Batch 时需要统一处理为 `input_ids`、`attention_mask`、`labels`。

#### 4.2 训练数据构造策略

Router 要学会"根据数据分布预测最优权重"，因此训练数据必须覆盖**多种不同的任务混合比例**：

* 从各任务的微调数据中划出一部分作为 Router 的训练集（建议使用验证集或留存集，避免与微调数据重叠）。
* 每个 Batch 随机采样不同比例的混合，例如：
    * 100% 法律 + 0% 其他
    * 20% 法律 + 50% 数学 + 20% 代码 + 10% 语言识别
    * 25% + 25% + 25% + 25%
    * 0% + 0% + 0% + 100% 数学
    * ... 各种随机比例
* **混合比例必须随机采样**，否则 Router 会过拟合到固定分布。
* 建议训练 1000~10000 个不同混合比例的 Batch。

#### 4.3 Batch 数据结构

```python
batch = {
    'input_ids':      Tensor,      # [Batch, Seq_Len]
    'attention_mask':  Tensor,      # [Batch, Seq_Len]
    'labels':         Tensor,      # [Batch] — 分类标签（各任务各自的类别标签）
    'task_ids':       List[str],   # ['law', 'law', 'math', 'code', 'langid', ...] — 每条样本的任务归属
}
```

**注意：** `task_ids` 仅在训练时使用。推理时客户数据无标注，由 Router 的 Task Classifier 自动预测。

#### 4.4 数据采样器实现建议

```python
# 伪代码：构建一个随机混合比例的 Batch
import numpy as np

def sample_mixed_batch(task_datasets, batch_size):
    """
    task_datasets: Dict[str, Dataset] — {
        'code': code_dataset, 
        'langid': langid_dataset,
        'law': law_dataset, 
        'math': math_dataset
    }
    """
    # 1. 随机生成混合比例（Dirichlet 分布保证和为 1）
    ratios = np.random.dirichlet(np.ones(len(task_datasets)))

    # 2. 按比例分配样本数
    counts = (ratios * batch_size).astype(int)
    counts[-1] = batch_size - counts[:-1].sum()  # 确保总数正确

    # 3. 从各任务数据集中随机采样
    samples = []
    task_ids = []
    for (task_name, dataset), count in zip(task_datasets.items(), counts):
        if count > 0:
            indices = np.random.choice(len(dataset), count, replace=False)
            samples.extend([dataset[i] for i in indices])
            task_ids.extend([task_name] * count)

    return collate(samples, task_ids)  # 整理成 Batch 格式
```

### 步骤 5：训练循环 (The Optimization Loop)

**说明：** 端到端梯度下降，同时训练 Router 的两个 Head。

**伪代码流程：**

1. **Input:** 获取一个随机混合比例的 Mixed Batch（含 `task_ids`）。

2. **Router Forward:**
    * 将 `input_ids` 和 `attention_mask` 输入 Router。
    * Router 输出：
        * `alphas`：合并权重，如 $[0.2, 0.0, 0.3, 0.8]$（Tensor, 带梯度，长度=4）。
        * `task_logits`：每条样本的任务分类 logits，$[Batch, 4]$。

3. **Task Classifier Loss（辅助损失）：**
    * 将 `task_ids` 转为数值标签 `task_labels`（如 code→0, langid→1, law→2, math→3）。
    * `task_cls_loss = CrossEntropyLoss(task_logits, task_labels)`。

4. **Dynamic Merge:**
    * 利用 `alphas` 和预存的 Task Vectors，计算 `merged_params`（**保留梯度链！**）。

5. **Task-Specific Merge Loss 计算：**
    * 初始化 `merge_loss = 0`。
    * **Split Batch：** 根据 `task_ids` 将 Batch 拆分为 sub-batches。
    * **For each sub-batch (task_name, sub_input_ids, sub_attention_mask, sub_labels):**
        * 用 `functional_call(base_model, merged_params, ...)` 得到 `output.hidden_states[-1]`。
        * 对 `hidden_states` 做 Mean Pooling + LayerNorm（与微调模型的 forward 一致）。
        * 将处理后的 `sentence_representation` 传入对应的 **Frozen Classification Head**（如 `heads[task_name]`）。
        * 计算 `CrossEntropyLoss(head_output, sub_labels)`。
        * `merge_loss += sub_task_loss / num_samples_in_sub_batch`（按样本数归一化，避免不同任务类别数导致 Loss 量级不一致）。

6. **Total Loss & Backward:**
    * `total_loss = merge_loss + λ * task_cls_loss`（λ 为辅助损失的权重系数，如 0.5）。
    * `total_loss.backward()`（梯度回传给 Router 的两个 Head）。
    * `optimizer.step()`。

7. **验证：**
    * 定期在验证集上评估：
        * 各任务的分类 **ACC**（使用 Router 预测的任务归属 + 合并后模型 + 对应 Head）。
        * Router 在不同混合比例下输出的 $\alpha$ 值（观察是否学到了"数学题多就调高数学权重"的规律）。
    * 以验证 ACC 作为模型选择（early stopping）的依据。

### 步骤 6：评估阶段 (Evaluation)

**说明：** 训练完成后，需要系统性地评估 Router 的三项核心能力：① Merge Head 的合并质量（单任务 ACC）；② Task Classifier 的任务识别准确率；③ 端到端系统在混合数据集上的全流程表现。评估使用**带标注的**测试集（与训练集不重叠）。

#### 6.1 评估一：合并效果评估（单任务 ACC）

**目的：** 逐一输入四个任务的测试集，由 Router 生成该数据集对应的合并权重 $\alpha$，用合并后模型 + 对应任务分类头进行评估，记录各任务的实际分类 ACC，并与微调模型 ACC 作为基线进行对比。

**理想行为：** 当输入 100% 的某单任务数据集时，Router 的最理想输出应当是：**该任务对应的 $\alpha_i = 1$，其余任务的 $\alpha_j = 0$**。例如输入纯数学测试集时，理想的 $\alpha = [0, 0, 0, 1]$（code=0, langid=0, law=0, math=1），此时合并后模型等价于数学微调模型本身，应能完全恢复微调模型的 ACC。$\alpha$ 与理想值的偏差程度直接反映了 Router 合并权重预测的质量。

**流程：** 依次输入 100% 的单任务测试数据集，记录 Router 输出的 $\alpha$ 值和合并后模型在该任务上的分类 ACC。

| 测试轮次 | 输入数据集 | 记录指标 | 理想 α (码/语/法/数) | 参考基线（微调模型 ACC）|
|---------|-----------|----------|---------------------|----------------------|
| 1 | 100% 代码测试集 | 代码分类 ACC | [1, 0, 0, 0] | ~83.90% |
| 2 | 100% 语言识别测试集 | 语言识别 ACC | [0, 1, 0, 0] | ~91.73% |
| 3 | 100% 法律测试集 | 法律分类 ACC | [0, 0, 1, 0] | ~70.57% |
| 4 | 100% 数学测试集 | 数学分类 ACC | [0, 0, 0, 1] | ~95.85% |

**评估指标说明：**
* **绝对 ACC**：合并模型在各任务上的分类准确率。
* **ACC 差距**：合并模型 ACC 与微调基线 ACC 的差值（越小越好，正值表示超越基线）。
* **归一化 ACC**：$\text{Normalized ACC} = \frac{\text{ACC}}{\text{Baseline ACC}} \times 100\%$，衡量合并模型相对于微调模型的性能保留率。100% 表示完全恢复微调 ACC，>100% 表示超越。
* **平均指标**：对所有任务的绝对 ACC 和归一化 ACC 分别取平均，作为整体评估指标。

**评估重点：**
* **归一化 ACC**：该指标消除了各任务难度差异的影响，使得不同任务的表现可以公平比较。例如数学 ACC=93% 对应归一化 97.03%，而法律 ACC=65% 对应归一化 92.13%，说明法律任务的性能保留率反而更低。
* **α 分布质量**：观察 Router 是否学到了"纯单任务输入时突出该任务权重"的规律。$\alpha$ 越接近理想的 one-hot 分布，说明 Router 对数据分布的感知能力越强。

#### 6.2 评估二：任务识别性能评估（混合数据集）

**目的：** 验证 Router 的 Task Classifier 能否正确识别混合数据集中每条样本所属的任务，以及在不同分布下 $\alpha$ 输出是否合理。

**测试数据集：** 构造不同混合比例的数据集。每个任务指定**绝对样本数**（而非比例），确保各任务有足够的评估数据：

| 数据集编号 | 代码 | 语言识别 | 法律 | 数学 | 总样本数 | 设计意图 |
|-----------|------|---------|------|------|---------|----------|
| Mix-A | 1000 | 1000 | 1000 | 1000 | 4000 | **均匀分布**：各任务相同样本数 |
| Mix-B | 2000 | 400 | 1200 | 400 | 4000 | **代码为主**：50% 代码数据 |
| Mix-C | 400 | 400 | 400 | 2800 | 4000 | **数学为主**：70% 数学数据 |
| Mix-D | 200 | 2400 | 200 | 1200 | 4000 | **语言识别为主**：60% 语言识别数据 |

> **注：** 各任务测试集大小参考：code≈23703, langid≈3000, law≈1400, math≈10000。上述配置确保不超过各任务测试集大小。

**评估指标：**

* **Task Classification ACC**：Router 预测的 `argmax(task_logits)` 与真实 `task_ids` 的匹配率。
* **Per-task Recall**：各任务的召回率（特别关注稀少任务是否被正确识别）。
* **Router 输出的 $\alpha$ 值**：观察合并权重是否与数据集的任务分布一致。对于以某任务为主的数据集，$\alpha$ 应对应突出该任务；对于均匀混合（Mix-A），$\alpha$ 应相对均衡。


#### 6.3 评估三：端到端系统评估（混合数据集）

**目的：** 模拟真实客户使用场景，验证完整系统的端到端性能。评估一隔离测试了 Merge Head，评估二隔离测试了 Task Classifier，评估三测试两者组合在一起的实际效果。

**流程：**
1. 输入混合数据集（Mix-A/B/C/D）
2. Router 遍历所有 batch，收集 α → 计算 **dataset-level** 全局 α（所有 batch α 的均值）
3. 用唯一一组全局 α 合并出**唯一一个**主干网络
4. 所有样本通过合并主干得到隐状态
5. **Task Classifier 自动选头**（使用 `argmax(task_logits)` 预测任务，不使用 ground truth）
6. 各任务分类头输出预测 → 与 ground truth 比较计算 ACC

**与评估一的关键区别：**
* 评估一用 ground truth 选头（隔离 Merge Head），评估三用 Task Classifier 自动选头（测试完整系统）
* 评估一逐 batch 生成 α 并合并，评估三使用 dataset-level 唯一 α
* 如果 Task Classifier 将样本判到错误的任务分类头，该样本必然分类错误

**评估指标：**
* **各任务下游 ACC**：合并主干 + Task Classifier 自动选头后的实际分类准确率
* **归一化 ACC**：与微调基线对比的性能保留率
* **错头率**：因 Task Classifier 误判导致样本送入错误分类头的比例
* **Router 输出的 dataset-level $\alpha$ 值**

**逻辑关系：** 如果评估一 ACC 高 + 评估二 ACC 高 → 评估三理应也高。如果评估一和评估二都好但评估三差，说明两个模块的交互或 α 聚合方式有问题。


#### 6.4 评估结果汇总表格（建议输出格式）

```
==================== 评估报告 ====================

--- 评估一：合并效果评估（单任务 ACC）---
| 任务     | α_code | α_langid | α_law  | α_math | ACC    | 基线 ACC | 差距    | 归一化  |
|----------|--------|----------|--------|--------|--------|---------|--------|---------|
| code     |        |          |        |        |        | 83.90%  |        |         |
| langid   |        |          |        |        |        | 91.73%  |        |         |
| law      |        |          |        |        |        | 70.57%  |        |         |
| math     |        |          |        |        |        | 95.85%  |        |         |
| 平均     |  —     |    —     |   —    |   —    | XX.XX% |   —     |   —    | XX.XX%  |

--- 评估二：任务识别性能评估（混合数据集）---
| 数据集 | 数量(码/语/法/数)      | Task ACC | α_code | α_langid | α_law  | α_math |
|--------|----------------------|----------|--------|----------|--------|--------|
| Mix-A  | 1000/1000/1000/1000  |          |        |          |        |        |
| Mix-B  | 2000/400/1200/400    |          |        |          |        |        |
| Mix-C  | 400/400/400/2800     |          |        |          |        |        |
| Mix-D  | 200/2400/200/1200    |          |        |          |        |        |

--- Per-task Recall (各任务召回率) ---
| 数据集 | code   | langid | law    | math   |
|--------|--------|--------|--------|--------|
| Mix-A  |        |        |        |        |
| Mix-B  |        |        |        |        |
| Mix-C  |        |        |        |        |
| Mix-D  |        |        |        |        |

--- 评估三：端到端系统评估（混合数据集 → 自动选头 → 下游 ACC）---
| 数据集 | α_code | α_langid | α_law  | α_math | code   | langid | law    | math   | 平均归一化 |
|--------|--------|----------|--------|--------|--------|--------|--------|--------|-----------|
| Mix-A  |        |          |        |        |        |        |        |        |           |
| Mix-B  |        |          |        |        |        |        |        |        |           |
| Mix-C  |        |          |        |        |        |        |        |        |           |
| Mix-D  |        |          |        |        |        |        |        |        |           |

--- 评估三：错头率（Task Classifier 误判导致）---
| 数据集 | code   | langid | law    | math   |
|--------|--------|--------|--------|--------|
| Mix-A  |        |        |        |        |
| Mix-B  |        |        |        |        |
| Mix-C  |        |        |        |        |
| Mix-D  |        |        |        |        |

```

### 步骤 7：推理与部署流程（面向客户）

**说明：** 训练完成后，Router 可以为新客户的无标注数据集生成最优合并方案。

**完整推理流程：**

```
客户提交无标注数据集
        ↓
  加载训练好的 Router
        ↓
  ┌─────────────────────────────────────┐
  │ 遍历数据集所有 Batch：                │
  │   Router → alphas_i, task_logits_i   │
  │ 聚合：                                │
  │   global_α = mean(所有 alphas_i)     │
  │   每条样本 task = argmax(logits)      │
  └─────────────────────────────────────┘
        ↓
  用 global_α 合并模型：
  merged_params = base + Σ(α_i * τ_i)
        ↓
  保存合并后的模型 + 分类头
        ↓
  交付给客户
```

**关键实现步骤：**

1. **加载资源：** 加载训练好的 Router、基座模型（`GPTNeoForCausalLM`）、Task Vectors、所有分类头。

2. **推理 Router（Dataset 级聚合）：**

```python
all_alphas = []
all_task_preds = []

TASK_NAMES = ['code', 'langid', 'law', 'math']

router.eval()
with torch.no_grad():
    for batch in customer_dataloader:
        alphas, task_logits = router(batch['input_ids'], batch['attention_mask'])
        all_alphas.append(alphas)
        all_task_preds.append(task_logits.argmax(dim=-1))  # 每条样本的任务预测

# Dataset 级别的全局合并权重（对所有 Batch 的 α 取平均）
global_alphas = torch.stack(all_alphas).mean(dim=0)  # [4]

# 每条样本的任务归属
all_task_preds = torch.cat(all_task_preds)  # [N]
# 将数值索引转为任务名
task_assignments = [TASK_NAMES[idx] for idx in all_task_preds.tolist()]
```

3. **合并模型并保存：**

```python
# 用全局 α 计算最终合并权重（此时不需要梯度）
with torch.no_grad():
    final_params = compute_merged_params(base_params, task_vectors, global_alphas)

# 方式一：直接保存合并后的 Backbone 权重
torch.save(final_params, "./merged_model/backbone_merged.pt")

# 方式二：构建完整模型并保存（推荐）
# 将合并后的权重加载到 GPTNeoForCausalLM 中
merged_state_dict = {k: v for k, v in final_params.items()}
base_model.load_state_dict(merged_state_dict)
base_model.save_pretrained("./merged_model/backbone")

# 保存所有分类头
for task_name, head in heads.items():
    torch.save(head.state_dict(), f"./merged_model/head_{task_name}.pt")

# 保存 Router 的任务预测结果（客户用于知道每条数据该用哪个 Head）
torch.save(all_task_preds, "./merged_model/sample_task_assignments.pt")

# 保存任务配置（客户需要知道各分类头的 num_classes）
import json
task_config = {name: {'num_classes': cfg['num_classes']} for name, cfg in TASK_CONFIGS.items()}
with open("./merged_model/task_config.json", 'w') as f:
    json.dump(task_config, f, indent=2)
```

4. **交付产物：**
    * `merged_model/backbone/` — 合并后的 GPT-Neo Backbone（可直接 `GPTNeoForCausalLM.from_pretrained()` 加载）。
    * `head_code.pt` (1006), `head_langid.pt` (6类), `head_law.pt` (13类), `head_math.pt` (25类) — 四个分类头权重。
    * `sample_task_assignments.pt` — 每条样本的任务归属预测（告诉客户第 i 条数据用哪个 Head）。
    * `task_config.json` — 各任务的配置信息（num_classes 等）。

## 4. 特别注意事项 (给 Claude 的提示)

1. **只训练 Router：** 整个系统中，只有 Router 的参数（`merge_head` 和 `task_classifier`）是可训练的。基座模型（`GPTNeoForCausalLM`）、Task Vectors、分类头全部冻结（`requires_grad=False`）。

2. **梯度链完整性：** `alphas` 从 Router 输出 → 进入 `compute_merged_params` → 通过 `functional_call` → 取 `hidden_states[-1]` → Mean Pooling + LayerNorm → 分类头 → 计算 Loss → `backward()`。这条梯度链**不能断裂**。确保 `alphas` 始终是带 `requires_grad=True` 的 Tensor。

3. **参数名前缀映射：** 微调模型的 state_dict 中，Backbone 参数名以 `base_model.` 开头（如 `base_model.transformer.h.0.attn.attention.k_proj.weight`），而 `GPTNeoForCausalLM` 的 `named_parameters()` 不含此前缀（如 `transformer.h.0.attn.attention.k_proj.weight`）。在计算 Task Vector 和使用 `functional_call` 时，务必使用**不含 `base_model.` 前缀**的参数名。

4. **隐状态后处理一致性：** 通过 `functional_call` 获取 Backbone 输出后，后处理步骤（Mean Pooling → LayerNorm）必须与微调模型的 `GPTNeoWithClassificationHead.forward` 中的逻辑**完全一致**，否则分类头的输出会不正确。

5. **显存优化：** 如果显存不足：
    * 使用 Gradient Checkpointing。
    * 减小 Batch Size。

6. **Loss 归一化：** 不同任务的类别数差异很大（code=1006, langid=6, law=13, math=25），CE Loss 天然量级不同。务必对各子任务的 Loss 取**平均**（除以子 Batch 样本数），而非直接求和。

7. **可扩展性：** 代码中 `num_tasks` 应设计为可配置参数，方便未来增加新任务（如医疗）。Router 的 MLP 输出维度、Task Vectors 字典、Heads 字典、`TASK_NAMES` 列表都应基于配置动态构建，避免硬编码为 4。

8. **模型结构说明：** 微调模型使用 `GPTNeoForCausalLM`（带 LM Head）作为 backbone，而非 `GPTNeoModel`（不带 LM Head）。虽然 LM Head 的权重也包含在 state_dict 中，但在分类任务中实际只使用 `hidden_states`（通过 `output_hidden_states=True` 获取），不使用 LM Head 的输出。在计算 Task Vector 时，LM Head 相关的参数（如 `lm_head.weight`）也应包含在内以保持完整性。
