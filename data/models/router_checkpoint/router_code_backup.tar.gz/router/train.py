"""
步骤5：训练循环 (The Optimization Loop)

端到端梯度下降，同时训练 Router 的两个 Head（Merge Head + Task Classifier）。
基座模型、Task Vectors、分类头全部冻结，只有 Router 参数可训练。

训练流程（每步）：
1. 获取 Dirichlet 随机混合比例的 Mixed Batch
2. Router Forward → alphas, task_logits
3. Task Classifier Loss（辅助 CE loss）
4. Dynamic Merge（alphas + Task Vectors → merged_params，保留梯度链）
5. Merge Loss（按任务拆分 Batch → 各分类头 → CE loss）
6. Total Loss = merge_loss + λ_cls * task_cls_loss + λ_α * α_reg → backward → optimizer.step
7. 定期在验证集评估（各任务 ACC + α 观察）
"""

import os
import sys
import time
import json
import logging
import argparse
import numpy as np
import torch
import torch.nn.functional as F
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    TASK_NAMES, TASK_CONFIGS, TASK_NAME_TO_IDX, IDX_TO_TASK_NAME,
    NUM_TASKS, HIDDEN_SIZE, ROUTER_DIR
)
from task_vectors import load_task_vectors_and_heads
from router import create_router
from merge import (compute_merged_params, compute_merge_loss, compute_total_loss,
                   merged_forward)
from data import (
    load_task_datasets, MixedBatchSampler,
    create_single_task_dataloader,
)

# ---------- Logging ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)


# ===== 训练超参数 =====
DEFAULT_HPARAMS = {
    'batch_size': 32,
    'num_epochs': 5,
    'batches_per_epoch': 1000,
    'learning_rate': 1e-3,
    'weight_decay': 1e-4,
    'lambda_task_cls': 0.5,      # 任务分类辅助 loss 的权重
    'dirichlet_alpha': 0.3,      # Dirichlet 浓度参数（<1 偏极端分布, >1 偏均匀）
    'lambda_alpha': 1.0,          # α 稀疏正则化权重（鼓励 α 趋向 0 或 1）
    'use_cosine_lr': True,        # 是否使用余弦退火学习率
    'max_samples_per_task': None, # None=使用全部训练数据
    'val_every': 200,            # 每 N 步验证一次
    'val_batches': 50,           # 验证时使用的 batch 数
    'val_samples_per_task': 500, # 验证集每任务采样数
    'save_dir': os.path.join(ROUTER_DIR, 'checkpoints'),
    'seed': 42,
    'grad_clip_norm': 1.0,       # 梯度裁剪范数
}

# ===== 基线 ACC（微调模型在测试集上的 ACC，用于模型选择）=====
BASELINE_ACC = {
    'code':   0.8390,
    'langid': 0.9173,
    'law':    0.7057,
    'math':   0.9585,
}


def make_run_dir_name(hp):
    """根据训练参数和当前时间生成运行目录名称。"""
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    parts = [
        timestamp,
        f"bs{hp['batch_size']}",
        f"lr{hp['learning_rate']}",
        f"ep{hp['num_epochs']}",
        f"bpe{hp['batches_per_epoch']}",
        f"lam{hp['lambda_task_cls']}",
        f"dir{hp['dirichlet_alpha']}",
        f"alp{hp.get('lambda_alpha', 1.0)}",
    ]
    if hp.get('use_cosine_lr', True):
        parts.append('cosLR')
    if hp.get('max_samples_per_task'):
        parts.append(f"maxs{hp['max_samples_per_task']}")
    return '_'.join(parts)


def set_seed(seed):
    """设置全局随机种子。"""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def move_to_device(obj, device):
    """将 dict 中的 Tensor 全部移到指定设备。"""
    if isinstance(obj, dict):
        return {k: move_to_device(v, device) for k, v in obj.items()}
    elif isinstance(obj, torch.Tensor):
        return obj.to(device)
    elif isinstance(obj, list):
        return obj  # task_ids 是 list[str]，不需要移动
    return obj


# ===== 验证函数 =====
@torch.no_grad()
def validate(router, base_model, base_params, task_vectors, heads,
             val_sampler, device, hparams):
    """
    在验证集上评估 Router 性能。

    返回:
        metrics: dict with keys:
            - val_loss: 平均 total loss
            - val_merge_loss: 平均 merge loss
            - val_task_cls_loss: 平均 task classifier loss
            - val_task_cls_acc: 任务分类准确率
            - per_task_acc: 各任务分类的 ACC（使用合并模型 + 对应 Head）
            - avg_alphas: 平均 α 值
    """
    router.eval()
    metrics = defaultdict(float)
    all_alphas = []
    task_correct = defaultdict(int)
    task_total = defaultdict(int)
    task_cls_correct = 0
    task_cls_total = 0
    num_batches = 0

    for batch in val_sampler:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)
        task_ids = batch['task_ids']

        # Router forward
        alphas, task_logits, _ = router(input_ids, attention_mask)
        all_alphas.append(alphas.cpu())

        # Task classifier loss + acc
        task_labels = torch.tensor(
            [TASK_NAME_TO_IDX[t] for t in task_ids], device=device
        )
        task_cls_loss = F.cross_entropy(task_logits, task_labels)
        task_preds = task_logits.argmax(dim=-1)
        task_cls_correct += (task_preds == task_labels).sum().item()
        task_cls_total += len(task_labels)

        # Merge loss
        merged_params = compute_merged_params(base_params, task_vectors, alphas)
        merge_loss = compute_merge_loss(
            base_model, merged_params, heads,
            input_ids, attention_mask, labels, task_ids
        )
        total_loss = compute_total_loss(merge_loss, task_cls_loss, hparams['lambda_task_cls'])

        metrics['val_loss'] += total_loss.item()
        metrics['val_merge_loss'] += merge_loss.item()
        metrics['val_task_cls_loss'] += task_cls_loss.item()

        # Per-task classification ACC (使用合并后模型)
        all_logits, all_indices = merged_forward(
            base_model, merged_params, heads,
            input_ids, attention_mask, task_ids
        )
        for task_name, logits in all_logits.items():
            idx = all_indices[task_name]
            sub_labels = labels[idx]
            preds = logits.argmax(dim=-1)
            task_correct[task_name] += (preds == sub_labels).sum().item()
            task_total[task_name] += len(sub_labels)

        num_batches += 1

    router.train()

    if num_batches == 0:
        return {}

    # Aggregate metrics
    for k in ['val_loss', 'val_merge_loss', 'val_task_cls_loss']:
        metrics[k] /= num_batches

    metrics['val_task_cls_acc'] = task_cls_correct / max(task_cls_total, 1)

    per_task_acc = {}
    for task_name in TASK_NAMES:
        if task_total[task_name] > 0:
            per_task_acc[task_name] = task_correct[task_name] / task_total[task_name]
        else:
            per_task_acc[task_name] = 0.0
    metrics['per_task_acc'] = per_task_acc

    avg_alphas = torch.stack(all_alphas).mean(dim=0)
    metrics['avg_alphas'] = avg_alphas.numpy()

    return dict(metrics)


# ===== 保存/加载 checkpoint =====
def _to_serializable(obj):
    """将 numpy 数组等转为纯 Python 类型，确保 torch.save 兼容 weights_only。"""
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {k: _to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return type(obj)(_to_serializable(v) for v in obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.integer):
        return int(obj)
    return obj


def save_checkpoint(router, optimizer, epoch, step, metrics, hparams, path):
    """保存训练 checkpoint。"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    checkpoint = {
        'router_state_dict': router.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'epoch': epoch,
        'step': step,
        'metrics': _to_serializable(metrics),
        'hparams': _to_serializable(hparams),
    }
    torch.save(checkpoint, path)
    logger.info(f"  Checkpoint 已保存: {path}")


def load_checkpoint(path, router, optimizer=None):
    """加载训练 checkpoint。"""
    checkpoint = torch.load(path, map_location='cpu', weights_only=False)
    router.load_state_dict(checkpoint['router_state_dict'], strict=False)
    if optimizer and 'optimizer_state_dict' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    return checkpoint


# ===== 训练主循环 =====
def train(hparams=None):
    """
    完整的训练流程。

    Args:
        hparams: dict, 可覆盖默认超参数
    """
    hp = {**DEFAULT_HPARAMS}
    if hparams:
        hp.update(hparams)

    # 创建以参数+时间命名的运行目录
    run_name = make_run_dir_name(hp)
    hp['save_dir'] = os.path.join(hp['save_dir'], run_name)
    os.makedirs(hp['save_dir'], exist_ok=True)

    set_seed(hp['seed'])
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 添加 FileHandler，将训练日志同时写入运行目录
    train_log_path = os.path.join(hp['save_dir'], 'train_log.txt')
    file_handler = logging.FileHandler(train_log_path, mode='a', encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
    logging.getLogger().addHandler(file_handler)

    logger.info(f"设备: {device}")
    logger.info(f"运行目录: {hp['save_dir']}")
    logger.info(f"训练日志: {train_log_path}")
    logger.info(f"超参数: {json.dumps({k: str(v) for k, v in hp.items()}, indent=2)}")

    # 保存超参数到文件
    with open(os.path.join(hp['save_dir'], 'hparams.json'), 'w') as f:
        json.dump({k: str(v) for k, v in hp.items()}, f, indent=2)

    # ===== 1. 加载模型组件 =====
    logger.info("\n" + "=" * 60)
    logger.info("加载模型组件...")
    logger.info("=" * 60)

    base_model, base_params, task_vectors, heads = load_task_vectors_and_heads()
    base_model = base_model.to(device)
    for key in base_params:
        base_params[key] = base_params[key].to(device)
    for task_name in task_vectors:
        for key in task_vectors[task_name]:
            task_vectors[task_name][key] = task_vectors[task_name][key].to(device)
    for task_name in heads:
        heads[task_name] = heads[task_name].to(device)

    router = create_router(base_model).to(device)
    logger.info(f"Router 可训练参数: {router.count_trainable_params():,}")

    # ===== 2. 优化器 + 学习率调度 =====
    optimizer = torch.optim.AdamW(
        router.get_trainable_params(),
        lr=hp['learning_rate'],
        weight_decay=hp['weight_decay'],
    )

    scheduler = None
    if hp.get('use_cosine_lr', True):
        from torch.optim.lr_scheduler import CosineAnnealingLR
        total_steps = hp['num_epochs'] * hp['batches_per_epoch']
        scheduler = CosineAnnealingLR(
            optimizer, T_max=total_steps, eta_min=hp['learning_rate'] * 0.01
        )
        logger.info(f"使用余弦退火 LR: {hp['learning_rate']} -> {hp['learning_rate'] * 0.01}")

    # ===== 3. 加载训练数据 =====
    logger.info("\n" + "=" * 60)
    logger.info("加载训练数据...")
    logger.info("=" * 60)

    train_datasets, _ = load_task_datasets(
        split='train', max_samples_per_task=hp['max_samples_per_task']
    )
    for name, ds in train_datasets.items():
        logger.info(f"  {name}: {len(ds)} 样本")

    # ===== 4. 加载验证数据 =====
    logger.info("加载验证数据...")
    val_datasets, _ = load_task_datasets(
        split='validation', max_samples_per_task=hp['val_samples_per_task']
    )
    for name, ds in val_datasets.items():
        logger.info(f"  {name} (val): {len(ds)} 样本")

    # ===== 5. 训练循环 =====
    logger.info("\n" + "=" * 60)
    logger.info("开始训练...")
    logger.info("=" * 60)

    best_norm_acc = 0.0
    global_step = 0
    train_history = []

    os.makedirs(hp['save_dir'], exist_ok=True)

    for epoch in range(hp['num_epochs']):
        logger.info(f"\n{'='*60}")
        logger.info(f"Epoch {epoch + 1}/{hp['num_epochs']}")
        logger.info(f"{'='*60}")

        # 每个 epoch 创建新的 sampler（不同的随机序列）
        train_sampler = MixedBatchSampler(
            task_datasets=train_datasets,
            batch_size=hp['batch_size'],
            num_batches=hp['batches_per_epoch'],
            dirichlet_alpha=hp['dirichlet_alpha'],
            seed=hp['seed'] + epoch,  # 每 epoch 不同种子
        )

        epoch_loss = 0.0
        epoch_merge_loss = 0.0
        epoch_task_cls_loss = 0.0
        epoch_alpha_reg = 0.0
        epoch_steps = 0

        router.train()
        for batch_idx, batch in enumerate(train_sampler):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)
            task_ids = batch['task_ids']

            # ----- Forward -----
            # 2. Router forward
            alphas, task_logits, per_sample_alphas = router(input_ids, attention_mask)

            # 3. Task Classifier Loss
            task_labels = torch.tensor(
                [TASK_NAME_TO_IDX[t] for t in task_ids], device=device
            )
            task_cls_loss = F.cross_entropy(task_logits, task_labels)

            # 4 + 5. Unified Dynamic Merge + Merge Loss
            # 用 batch-mean α 合并唯一的 backbone，与部署场景一致
            # Dirichlet 混合 batch 使得不同 batch 的任务比例不同 → α 也不同
            # Router 学会根据输入数据分布动态生成合适的合并权重
            merged_params = compute_merged_params(base_params, task_vectors, alphas)
            merge_loss = compute_merge_loss(
                base_model, merged_params, heads,
                input_ids, attention_mask, labels, task_ids
            )

            # α 稀疏正则化：对 per-sample α 施加（鼓励每个样本的 α 趋向 0 或 1）
            alpha_reg = (per_sample_alphas * (1 - per_sample_alphas)).mean()

            # 6. Total Loss = merge_loss + λ_cls * task_cls_loss + λ_α * α_reg
            total_loss = (
                merge_loss
                + hp['lambda_task_cls'] * task_cls_loss
                + hp['lambda_alpha'] * alpha_reg
            )

            optimizer.zero_grad()
            total_loss.backward()

            # ----- Clip & Step -----
            if hp['grad_clip_norm'] > 0:
                torch.nn.utils.clip_grad_norm_(
                    router.parameters(), hp['grad_clip_norm']
                )
            optimizer.step()

            # ----- LR Schedule -----
            if scheduler is not None:
                scheduler.step()

            # ----- Logging -----
            epoch_loss += total_loss.item()
            epoch_merge_loss += merge_loss.item()
            epoch_task_cls_loss += task_cls_loss.item()
            epoch_alpha_reg += alpha_reg.item()
            epoch_steps += 1
            global_step += 1

            if (batch_idx + 1) % 50 == 0:
                avg_loss = epoch_loss / epoch_steps
                avg_ml = epoch_merge_loss / epoch_steps
                avg_tcl = epoch_task_cls_loss / epoch_steps
                avg_ar = epoch_alpha_reg / epoch_steps
                alpha_str = np.array2string(
                    alphas.detach().cpu().numpy(), precision=3, separator=', '
                )
                cur_lr = optimizer.param_groups[0]['lr']
                logger.info(
                    f"  [{epoch+1}/{hp['num_epochs']}] "
                    f"Step {batch_idx+1}/{hp['batches_per_epoch']}: "
                    f"loss={avg_loss:.4f} "
                    f"(merge={avg_ml:.4f}, task_cls={avg_tcl:.4f}, α_reg={avg_ar:.4f}) "
                    f"lr={cur_lr:.6f} α={alpha_str}"
                )

            # ----- Validation -----
            if global_step % hp['val_every'] == 0:
                logger.info(f"\n  --- 验证 (step={global_step}) ---")
                # 使用固定混合比例验证（均匀分布），消除 Dirichlet 随机性
                # 确保每次验证条件一致，结果可比较
                val_sampler = MixedBatchSampler(
                    task_datasets=val_datasets,
                    batch_size=hp['batch_size'],
                    num_batches=hp['val_batches'],
                    dirichlet_alpha=1000.0,  # 极大值 → 近似均匀分布
                    seed=hp['seed'],  # 固定种子，每次验证条件一致
                )
                val_metrics = validate(
                    router, base_model, base_params, task_vectors, heads,
                    val_sampler, device, hp
                )
                if val_metrics:
                    alpha_str = np.array2string(
                        val_metrics['avg_alphas'], precision=3, separator=', '
                    )
                    logger.info(
                        f"  val_loss={val_metrics['val_loss']:.4f} "
                        f"(merge={val_metrics['val_merge_loss']:.4f}, "
                        f"task_cls={val_metrics['val_task_cls_loss']:.4f})"
                    )
                    logger.info(
                        f"  task_cls_acc={val_metrics['val_task_cls_acc']:.2%}  "
                        f"avg_α={alpha_str}"
                    )
                    per_acc = val_metrics['per_task_acc']
                    for t_name in TASK_NAMES:
                        logger.info(f"    {t_name} ACC: {per_acc.get(t_name, 0):.2%}")

                    # 计算平均归一化 ACC
                    val_norm_acc = np.mean([
                        per_acc.get(t, 0) / BASELINE_ACC[t]
                        for t in TASK_NAMES
                    ])
                    logger.info(f"    平均归一化 ACC: {val_norm_acc:.2%}")

                    # 记录历史
                    train_history.append({
                        'step': global_step,
                        'epoch': epoch + 1,
                        'train_loss': epoch_loss / epoch_steps,
                        **{k: v for k, v in val_metrics.items()
                           if k not in ('per_task_acc', 'avg_alphas')},
                        'per_task_acc': {k: round(v, 4) for k, v in per_acc.items()},
                        'avg_alphas': val_metrics['avg_alphas'].tolist(),
                        'val_norm_acc': round(float(val_norm_acc), 4),
                    })

                    # 模型选择：使用平均归一化 ACC（而非 val_loss）
                    if val_norm_acc > best_norm_acc:
                        best_norm_acc = val_norm_acc
                        save_checkpoint(
                            router, optimizer, epoch, global_step,
                            val_metrics, hp,
                            os.path.join(hp['save_dir'], 'best_router.pt')
                        )
                        logger.info(f"  ★ 新最佳模型 (norm_acc={best_norm_acc:.2%})")

        # Epoch summary
        avg_loss = epoch_loss / max(epoch_steps, 1)
        logger.info(f"\nEpoch {epoch+1} 完成: avg_loss={avg_loss:.4f}")

        # 每 epoch 结束也保存一次 checkpoint
        save_checkpoint(
            router, optimizer, epoch, global_step, {}, hp,
            os.path.join(hp['save_dir'], f'router_epoch{epoch+1}.pt')
        )

    # ===== 6. 训练结束 =====
    logger.info("\n" + "=" * 60)
    logger.info("训练完成！")
    logger.info(f"  总步数: {global_step}")
    logger.info(f"  最佳归一化 ACC: {best_norm_acc:.2%}")
    logger.info(f"  Checkpoints: {hp['save_dir']}/")
    logger.info("=" * 60)

    # 保存训练历史
    history_path = os.path.join(hp['save_dir'], 'train_history.json')
    with open(history_path, 'w') as f:
        json.dump(train_history, f, indent=2)
    logger.info(f"训练历史已保存: {history_path}")

    # 移除 FileHandler，避免后续日志继续写入
    logging.getLogger().removeHandler(file_handler)
    file_handler.close()

    return router, train_history


# ===== CLI 入口 =====
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Train Router')
    parser.add_argument('--batch_size', type=int, default=DEFAULT_HPARAMS['batch_size'])
    parser.add_argument('--num_epochs', type=int, default=DEFAULT_HPARAMS['num_epochs'])
    parser.add_argument('--batches_per_epoch', type=int, default=DEFAULT_HPARAMS['batches_per_epoch'])
    parser.add_argument('--lr', type=float, default=DEFAULT_HPARAMS['learning_rate'])
    parser.add_argument('--lambda_task_cls', type=float, default=DEFAULT_HPARAMS['lambda_task_cls'])
    parser.add_argument('--dirichlet_alpha', type=float, default=DEFAULT_HPARAMS['dirichlet_alpha'])
    parser.add_argument('--lambda_alpha', type=float, default=DEFAULT_HPARAMS['lambda_alpha'])
    parser.add_argument('--no_cosine_lr', action='store_true', help='禁用余弦退火学习率')
    parser.add_argument('--val_every', type=int, default=DEFAULT_HPARAMS['val_every'])
    parser.add_argument('--max_samples', type=int, default=None)
    parser.add_argument('--seed', type=int, default=DEFAULT_HPARAMS['seed'])
    parser.add_argument('--save_dir', type=str, default=DEFAULT_HPARAMS['save_dir'])
    args = parser.parse_args()

    hparams = {
        'batch_size': args.batch_size,
        'num_epochs': args.num_epochs,
        'batches_per_epoch': args.batches_per_epoch,
        'learning_rate': args.lr,
        'lambda_task_cls': args.lambda_task_cls,
        'dirichlet_alpha': args.dirichlet_alpha,
        'lambda_alpha': args.lambda_alpha,
        'use_cosine_lr': not args.no_cosine_lr,
        'val_every': args.val_every,
        'max_samples_per_task': args.max_samples,
        'seed': args.seed,
        'save_dir': args.save_dir,
    }

    train(hparams)
