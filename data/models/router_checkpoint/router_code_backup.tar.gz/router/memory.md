# Router 开发记录

---

## 模型 1：20260227_191859_bs32_lr0.001_ep5_bpe1000_lam0.5_alp1.0_dir0.3

**架构特点：**
- Merge Head 输入 = embedding(768) ⊕ task_probs(4) = 772 维
- 统一 α（batch 均值）+ 统一 backward
- α 稀疏正则化（lambda_alpha=1.0）
- 无 cosine LR，无 diversity loss

**评估结果（平均归一化 ACC = 96.23%）：**

| 任务 | ACC | 基线 | 归一化 |
|------|-----|------|--------|
| code | 87.80% | 83.90% | 104.65% |
| langid | 90.57% | 91.73% | 98.73% |
| law | 62.50% | 70.57% | 88.56% |
| math | 89.10% | 95.85% | 92.96% |

**α 特性：** 强任务区分性。code 输入→α_code=0.853, langid→α_langid=0.998。混合 Task ACC ≥ 94.92%。

---

## 模型 2：20260228_120857_bs32_lr0.0005_ep8_bpe1500_lam1.0_dir0.2

**架构特点：**
- 早期实验版本
- lr=0.0005, 8 epochs, batch_per_epoch=1500
- lambda_task_cls=1.0

**评估结果（平均归一化 ACC = 85.24%）：**

| 任务 | ACC | 基线 | 归一化 |
|------|-----|------|--------|
| code | 64.03% | 83.90% | 76.32% |
| langid | 84.77% | 91.73% | 92.41% |
| law | 60.93% | 70.57% | 86.34% |
| math | 82.33% | 95.85% | 85.90% |

**α 特性：** α 坍塌严重，四个任务输出的 α 几乎一致。

---

## 模型 3：20260302_082639_bs32_lr0.001_ep5_bpe1000_lam0.3_div0.3_adw0.1_cosLR

**架构特点（相对模型 1 的"改进"，实际全面劣化）：**
- 新增 embed_proj（768→64→32），merge head 输入降为 36 维
- Per-task 梯度累积（retain_graph=True），各任务组单独 backward
- 新增 diversity loss（α 余弦相似度正则化）
- 新增 cosine LR
- lambda_task_cls 降为 0.3

**评估结果（平均归一化 ACC = 85.38%，较模型 1 下降 10.85pp）：**

| 任务 | ACC | 基线 | 归一化 |
|------|-----|------|--------|
| code | 71.24% | 83.90% | 84.91% |
| langid | 85.00% | 91.73% | 92.66% |
| law | 57.43% | 70.57% | 81.38% |
| math | 79.14% | 95.85% | 82.57% |

**α 特性：** α 完全坍塌，各维度差异 < 0.003。Best model 在 Step 600 即选中（task_cls_acc 仅 78%）。

---

## 对话记录

### 对话 1（2026-02-27 之前）
- **目的：** 初始实现 Router 六步框架（config → task_vectors → router → data → train → evaluate）
- **成果：** 生成模型 1（20260227），平均归一化 ACC 96.23%

### 对话 2（2026-02-28 ~ 2026-03-01）
- **目的：** 诊断并改进 Router 训练
- **诊断：** 识别出 α 坍塌、梯度冲突、训练不稳定等问题
- **改动：** 在 router.py 加入 embed_proj（768→32），train.py 加入 per-task 梯度累积 + diversity loss + cosine LR
- **问题：** 首次运行 OOM，修复后成功训练（添加 retain_graph=True）
- **成果：** 生成模型 3（20260302），但性能全面劣化

### 对话 3（2026-03-02）
- **目的：** 更新 code 基线 ACC 从 69.50% 到 83.90%
- **改动：** 更新 evaluate.py 中的 BASELINE_ACC，以及所有 checkpoints/eval_results 中的 evaluation_report.txt、eval_log.txt、evaluation_results.json

### 对话 4（2026-03-02，当前）
- **目的：** 诊断模型 3 的劣化原因，回退有害改动
- **诊断：**
  1. embed_proj 导致信息丢失（772→36 维），merge head 无法区分不同内容
  2. per-task 梯度累积 + retain_graph 导致梯度冲突，α 坍塌到均值
  3. diversity loss 与 merge loss 梯度方向冲突
  4. 模型选择标准（val_loss）与实际目标（归一化 ACC）不匹配
- **改动（router.py）：**
  - 移除 embed_proj，恢复 772 维 merge head 输入
  - 移除 _init_weights 和 get_trainable_params 中的 embed_proj 引用
- **改动（train.py）：**
  - 移除 per-task 梯度累积，恢复统一 backward
  - 移除 diversity loss
  - 恢复 α 稀疏正则化（lambda_alpha=1.0）
  - 模型选择改为平均归一化 ACC（而非 val_loss）
  - lambda_task_cls 恢复为 0.5
  - 保留 cosine LR
- **待验证：** 下次训练应恢复到模型 1 水平（归一化 ACC ≥ 96%）
