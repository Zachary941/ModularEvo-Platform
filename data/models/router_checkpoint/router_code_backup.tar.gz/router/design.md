## 整体思路梳理

根据代码分析，你的系统核心流程是：

1. **Task Vector 提取**（`task_vectors.py`）：计算微调模型与预训练模型的权重差异
2. **Router 网络**（`router.py`）：基于输入数据自动学习各 task vector 的混合系数
3. **权重合并**（`merge.py`）：将 router 输出的系数用于加权合并 task vectors
4. **训练与评估**（`train.py` / `evaluate.py`）：端到端训练 router 并评估合并后模型

---

## 4.1 引言

### 撰写要点

**第一段：背景与动机**

- 传统方法（ensemble、distillation）计算开销大，模型数量增长时不可扩展

- 在第三章算法设计的时候发现现有方法的问题（这里可以参照论文进行一定的修改）

  > 在模型协同复用场景中，面临两个核心挑战：（1）如何自动确定各源模型对目标任务的知识贡献程度，即合并系数的自动学习问题；（2）合并后的模型 backbone 需要搭配何种分类头才能适配目标任务，即分类头的自动选择问题。传统方法通常需要人工逐一尝试不同系数组合和分类头配置，效率低下且难以扩展。本节对上述两个问题进行形式化定义。

**第二段：现有工作及不足**

- 介绍 Task Arithmetic（Ilharco et al., 2023）：通过权重空间的算术运算合并模型
- 介绍 TIES-Merging、DARE 等手动/半自动合并方法
- **不足**：现有方法大多使用固定的合并系数（均匀权重或通过网格搜索来寻找最优参数，网格搜索会花费大量的时间，尤其是在任务变多的情况下，例如四个任务从0.1-1.3以0.1为间隔进行网格搜索，就需要13的四次方乘以四的推理次数，花费大量的时间和资源成本），缺乏自适应性

**第三段：本章方案概述**

- 参考你代码中的设计：提出一种基于轻量级 Router 网络自动学习 task vector 混合系数的方法
- 核心思想：不同任务的 task vector 对目标任务的贡献不同，应由数据驱动地决定合并权重

**第四段：本章组织结构**

tips：可以适当补充加一张**概念对比图**：传统方法 vs 本文方法的示意图（手动系数 vs 自动路由）

---

## 4.2 算法设计方法（建议 8-9 页）

这是核心章节，建议拆分为以下子节：

---

### 4.2.1 问题定义与符号说明 — 详细撰写指南

#### （1）基本符号

提醒：**与第三章保持一致的符号**，建议用表格形式汇总：

| 符号                       | 含义                             | 对应代码                         |
| -------------------------- | -------------------------------- | -------------------------------- |
| $\theta_{\text{pre}}$      | 预训练模型参数                   | `PRETRAINED_MODEL_NAME`          |
| $\theta_{\text{ft}}^{(k)}$ | 第 $k$ 个微调模型参数            | `FINETUNED_MODEL_NAMES[k]`       |
| $K$                        | 源微调模型总数                   | `len(FINETUNED_MODEL_NAMES)` = 7 |
| $\tau^{(k)}$               | 第 $k$ 个 task vector            | `task_vectors[k]`                |
| $\alpha_k$                 | 第 $k$ 个 task vector 的混合系数 | `coefficients[k]`                |
| $h^{(k)}$                  | 第 $k$ 个微调模型的分类头参数    | `heads/model_k_head.pt`          |

#### （2）问题一：Task Vector 合并系数的自动学习（约0.4页）

**定义 4.1（Task Vector）**：给定预训练模型参数 $\theta_{\text{pre}}$ 和第 $k$ 个微调模型参数 $\theta_{\text{ft}}^{(k)}$，task vector 定义为二者在权重空间中的差异：

$$\tau^{(k)} = \theta_{\text{ft}}^{(k)} - \theta_{\text{pre}}, \quad k = 1, 2, \ldots, K$$

**定义 4.2（权重合并）**：合并后的模型 backbone 参数为：

$$\theta^* = \theta_{\text{pre}} + \sum_{k=1}^{K} \alpha_k \cdot \tau^{(k)}$$

其中 $\alpha_k \in [0, 1]$ 为第 $k$ 个 task vector 的混合系数。

**问题 4.1（系数自动学习）**：给定目标任务的训练集 $\mathcal{D}_{\text{target}} = \{(x_i, y_i)\}_{i=1}^{N}$，求解最优混合系数 $\boldsymbol{\alpha}^* = (\alpha_1^*, \alpha_2^*, \ldots, \alpha_K^*)$，使得合并后的模型在目标任务上的损失最小：

$$\boldsymbol{\alpha}^* = \arg\min_{\boldsymbol{\alpha}} \frac{1}{N} \sum_{i=1}^{N} \mathcal{L}\left(f\left(x_i; \theta_{\text{pre}} + \sum_{k=1}^{K} \alpha_k \cdot \tau^{(k)}, h\right), y_i\right)$$

> **关键之处**：不同于 Task Arithmetic 中手动设定统一缩放因子 $\lambda$，本文为每个 task vector 学习独立的系数 $\alpha_k$，且由一个参数化的 Router 网络 $R_\phi$ 根据输入数据自动预测：

$$\boldsymbol{\alpha} = R_\phi(\mathbf{z})$$

其中 $\mathbf{z}$ 为模型元信息编码向量（详见 4.2.3 节），$\phi$ 为 Router 网络的可训练参数。

> **公式注解**：使用 sigmoid 函数将输出约束在 $[0, 1]$ 区间内，每个 $\alpha_k$ 独立预测而非使用 softmax 归一化，这允许多个 task vector 同时以较高权重被选入——物理含义是不同源模型可能从不同维度对目标任务有互补贡献。

#### （3）问题二：分类头的自动选择（约0.4页）

**这是本文方法区别于已有工作的又一重要特点**。

> 合并 task vector 仅解决了 backbone（编码器）的知识融合问题，但模型要完成分类任务，还需要一个合适的分类头（classification head）。由于各源微调模型的分类头可能具有不同的输出维度和语义空间，直接使用任意分类头会导致标签空间不匹配。

**定义 4.3（分类头集合）**：给定 $K$ 个微调模型，提取其分类头参数集合：

$$\mathcal{H} = \{h^{(k)} \mid h^{(k)} = \text{Head}(\theta_{\text{ft}}^{(k)}), \; k = 1, 2, \ldots, K\}$$

其中 $h^{(k)}$ 包含分类头的权重矩阵 $W_h^{(k)} \in \mathbb{R}^{C_k \times d}$ 和偏置向量 $b_h^{(k)} \in \mathbb{R}^{C_k}$，$C_k$ 为第 $k$ 个模型的类别数，$d$ 为 backbone 输出维度。

**问题 4.2（分类头自动选择）**：从候选分类头集合 $\mathcal{H}$ 中选择最适合目标任务的分类头：

$$h^* = \arg\max_{h^{(k)} \in \mathcal{H}_{\text{compatible}}} \text{Score}(h^{(k)}, \mathcal{D}_{\text{target}})$$

其中 $\mathcal{H}_{\text{compatible}} = \{h^{(k)} \mid C_k = C_{\text{target}}\}$ 为类别数与目标任务兼容的候选子集。

> **自动化策略**：本文将分类头的选择也纳入 Router 网络的联合优化框架中。具体地，Router 同时输出一个分类头选择分布 $\boldsymbol{\beta} = (\beta_1, \beta_2, \ldots, \beta_{|\mathcal{H}_{\text{compatible}}|})$：

$$\boldsymbol{\beta} = \text{Softmax}(R_\phi^{\text{head}}(\mathbf{z}))$$

$$h^* = h^{(\arg\max_k \beta_k)}$$

#### （4）联合优化目标（约0.3页）

> 综合问题 4.1 和问题 4.2，本章的核心目标是**联合学习** Router 网络参数 $\phi$，使其同时自动确定最优的 task vector 混合系数 $\boldsymbol{\alpha}$ 和最优分类头 $h^*$：

$$\phi^* = \arg\min_{\phi} \; \mathbb{E}_{(x,y) \sim \mathcal{D}_{\text{target}}} \left[ \mathcal{L}_{\text{task}} + \lambda_{\text{dir}} \cdot \mathcal{L}_{\text{dir}} + \lambda_{\text{reg}} \cdot \mathcal{L}_{\text{reg}} \right]$$

其中三个损失项分别约束：

- $\mathcal{L}_{\text{task}}$：合并后模型在目标任务上的分类性能
- $\mathcal{L}_{\text{dir}}$：task vector 合并方向的一致性
- $\mathcal{L}_{\text{reg}}$：防止系数退化的正则化项

对应训练代码中的损失计算：

````python
# 总损失计算对应公式中的三项
loss = lam * task_loss + dir_weight * direction_loss + alpha_reg * reg_loss
````

> 该联合优化框架将原本需要穷举搜索的组合优化问题（K 个系数 × |H| 个分类头），转化为一个端到端可微的参数学习问题，通过梯度下降高效求解。

#### （5）与第三章符号的衔接说明

在正文中加一段过渡：

> 本章沿用第三章中定义的模型参数空间表示。其中 $\theta_{\text{pre}}$ 与第三章中的预训练模型参数记号一致，$\tau^{(k)}$ 作为第三章中模型差异度量的具体实现形式（即权重空间的向量差），$\alpha_k$ 对应第三章中讨论的模块贡献度系数。本章进一步将第三章中通过规则/启发式方法确定的贡献度系数替换为可学习的 Router 网络预测，实现了从"手动设定"到"自动学习"的升级

### 4.2.2 Router 网络设计（2-2.5 页）

这是最核心的设计，对应 `router.py`：

````python
# filepath: router.py 核心架构
class TaskRouter(nn.Module):
    def __init__(self, input_dim, num_tasks, hidden_dim=256):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
        )
        self.coefficient_head = nn.Linear(hidden_dim // 2, num_tasks)
    
    def forward(self, x):
        """输入: batch 的特征表示; 输出: 每个 task vector 的混合系数"""
        h = self.encoder(x)
        coefficients = self.coefficient_head(h)  # 可学习的混合系数
        # 使用 sigmoid 或 softmax 约束系数范围
        coefficients = torch.sigmoid(coefficients)
        return coefficients
````

**撰写要点**：

- 输入特征的设计：如何用预训练模型提取输入数据的表示作为 Router 输入
- 网络结构选择的理由（轻量级 MLP，相比 Transformer 结构更高效）
- 输出激活函数的选择（sigmoid vs softmax 的权衡）
- **参数量分析**：Router 参数量远小于原始模型，体现轻量级

**可以补充的内容**：

- 加一张 **Router 网络结构图**
- 补充 Router 参数量与原始模型参数量的**对比表格**

### 4.2.4 训练策略与损失函数设计（2-2.5 页）

对应 `train.py` 中的训练逻辑：

````python
# filepath: train.py 损失函数与训练核心
# 根据 hparams.json 中的参数设计
# lambda (lam): 0.5-1.0 -- 任务损失权重
# direction loss (dir): 0.2-0.3 -- 方向约束
# alpha: 1.0 -- 正则化权重

def compute_loss(predictions, targets, coefficients, lambda_task, lambda_dir, alpha):
    """
    总损失 = λ_task * L_task + λ_dir * L_direction + α * L_reg
    """
    # 1. 任务损失: 合并后模型在目标任务上的交叉熵
    task_loss = F.cross_entropy(predictions, targets)
    
    # 2. 方向损失: 鼓励合并后的 task vector 与目标方向一致
    direction_loss = compute_direction_loss(coefficients, task_vectors)
    
    # 3. 正则化损失: 防止系数退化（全零或全一）
    reg_loss = regularization(coefficients)
    
    total_loss = lambda_task * task_loss + lambda_dir * direction_loss + alpha * reg_loss
    return total_loss
````

**撰写要点**：

- 三个损失项的详细数学公式和直觉解释
- **方向损失**的设计动机：确保合并方向与目标任务一致性
- 超参数设置（从 `hparams.json` 可以获取历次实验参数）
- 训练技巧：batch size、学习率调度、early stopping

**可以补充的内容**：

- 加一个**超参数敏感性分析**的表格/图（你有多次实验记录可以利用）
- 训练曲线图（loss 和 accuracy 随 epoch 变化）

### 4.2.5 算法伪代码（0.5-1 页）

根据你的完整流程，设计如下伪代码：

```
算法 4.1: 基于权重集成的模型自动协同复用算法

输入: 预训练模型 θ_pre, K个微调模型 {θ_ft^(k)}, 目标任务数据集 D_target
输出: 合并后的模型参数 θ*

阶段一：Task Vector 提取
1:  for k = 1 to K do
2:      τ^(k) ← θ_ft^(k) - θ_pre          // 计算 task vector
3:      将 τ^(k) 序列化保存至磁盘
4:  end for

阶段二：模型元信息编码
5:  for k = 1 to K do
6:      提取模型 k 的 head 层权重及结构描述
7:      计算 task vector 统计特征（范数、方向等）
8:      构建元信息向量 m^(k)
9:  end for

阶段三：Router 训练
10: 初始化 Router 网络 R_φ
11: for epoch = 1 to E do
12:     for each batch (x, y) ∈ D_target do
13:         h ← Encode(x; θ_pre)             // 用预训练模型提取特征
14:         α ← R_φ(h)                       // Router 预测混合系数
15:         θ_merged ← θ_pre + Σ_k α_k · τ^(k)  // 权重合并
16:         ŷ ← Forward(x; θ_merged)         // 前向推理
17:         L ← λ·L_task(ŷ,y) + λ_d·L_dir(α) + α_r·L_reg(α)
18:         更新 φ ← φ - η·∇_φ L
19:     end for
20:     if 验证集性能提升 then 保存最佳 Router
21: end for

阶段四：推理部署
22: 加载最佳 Router R_φ*
23: 对新输入 x: α* ← R_φ*(Encode(x; θ_pre))
24: θ* ← θ_pre + Σ_k α*_k · τ^(k)
25: return θ*
```

建议把这个伪代码用 **algorithm 环境**（LaTeX 的 `algorithm2e` 或 `algorithmic`）排版，再配一张**整体流程图**展示四个阶段的关系。

---

## 4.3 实验与结果分析（建议 5-6 页）

```
4.3 实验与结果分析
├── 4.3.1 实验设置
├── 4.3.2 实验一：合并模型的分类性能评估（对应评估一）
├── 4.3.3 实验二：混合数据集上的任务识别性能评估（对应评估二-任务识别部分）
├── 4.3.4 实验三：不同数据分布下的路由泛化性评估（对应评估二-α分布部分）
└── 4.3.5 综合分析与讨论
```

---

### 4.3.1 实验设置（建议 1.5-2 页）

#### 内容一：实验环境与基础配置

**硬件/软件环境表格**：GPU 型号、显存、PyTorch 版本、transformers 版本等。

**基座模型与微调模型**：

根据 `config.py` 和 guide.md，列出所有模型信息：

| 编号 | 任务名称              | 数据集                    | 类别数 $C_k$ | 微调方式               | 基线 ACC |
| ---- | --------------------- | ------------------------- | ------------ | ---------------------- | -------- |
| A    | 代码语言分类 (code)   | code (Parquet)            | 707          | mask-based (rate=0.25) | 69.50%   |
| B    | 欧洲语言识别 (langid) | langid (CSV)              | 6            | mask-based (rate=0.25) | 91.73%   |
| C    | 法律分类 (law/SCOTUS) | lex_glue/scotus (Parquet) | 13           | mask-based (rate=0.25) | 70.57%   |
| D    | 数学QA分类 (math)     | mathqa (Parquet)          | 25           | mask-based (rate=0.25) | 95.85%   |

> **撰写要点**：强调所有微调模型均基于同一个 GPT-Neo 125M 基座，采用模块化稀疏微调（mask_rate=0.25），这使得 task vector 天然稀疏，为后续合并提供了良好的基础。

#### 内容二：Router 训练配置

从你的多次实验 checkpoint 中，选取最终采用的配置（建议选 `20260228` 或 `20260227_191859` 那组）：

| 超参数                        | 值             | 说明                       |
| ----------------------------- | -------------- | -------------------------- |
| batch_size                    | 32             | 混合批次大小               |
| learning_rate                 | 0.001 / 0.0005 | Router 网络学习率          |
| epochs                        | 5 / 8          | 训练轮次                   |
| $\lambda_{\text{task}}$ (lam) | 0.5 / 1.0      | 任务分类损失权重           |
| $\lambda_{\text{dir}}$ (dir)  | 0.2 / 0.3      | 方向约束损失权重           |
| $\alpha_{\text{reg}}$ (alp)   | 1.0            | 正则化权重                 |
| batches_per_epoch             | 1000 / 1500    | 每轮训练批次数             |
| 混合比例采样                  | Dirichlet 分布 | 保证训练时覆盖多种任务配比 |

#### 内容三：评估指标定义

列出本节使用的所有指标及其数学定义：

- **绝对准确率 (ACC)**：$\text{ACC} = \frac{\text{正确预测样本数}}{\text{总样本数}} \times 100\%$
- **归一化准确率 (Normalized ACC)**：$\text{Norm\_ACC} = \frac{\text{合并模型 ACC}}{\text{基线微调模型 ACC}} \times 100\%$，衡量性能保留率
- **ACC 差距 (Gap)**：$\Delta\text{ACC} = \text{合并模型 ACC} - \text{基线 ACC}$
- **任务识别准确率 (Task Classification ACC)**：Router 的 task classifier 输出与真实任务标签的匹配率
- **各任务召回率 (Per-task Recall)**：$\text{Recall}_k = \frac{TP_k}{TP_k + FN_k}$

#### 内容四：对比方法（基线）

为了凸显自动化的优势，需要设置对比基线方法：

| 方法                   | 说明                                   |
| ---------------------- | -------------------------------------- |
| **Individual FT**      | 各微调模型单独使用（性能上限参考）     |
| **Uniform Merge**      | 所有 $\alpha_k = 0.25$，均匀合并       |
| **Manual Grid Search** | 网格搜索最佳 $\alpha$ 组合（穷举基线） |
| TIES-merging           | 网格搜索最佳 $\alpha$ 组合（穷举基线） |
| DARE                   | 网格搜索最佳 $\alpha$ 组合（穷举基线） |
| **本文方法 (Router)**  | Router 自动预测 $\alpha$ 和分类头      |

> 如果时间/算力不允许全部实验，至少保留 **Individual FT**（上限）、**Uniform Merge**（朴素基线）和**本文方法**三组对比。

---

### 4.3.2 实验一：合并模型的分类性能评估

#### 实验目的

> 验证 Router 自动预测的合并系数 $\boldsymbol{\alpha}$ 的有效性。核心问题：合并后的单一模型 backbone 能否在各任务上逼近甚至达到各微调模型的分类性能？

#### 实验方法

对应 guide.md 中的**评估一**：

- 依次输入 **100% 的单任务测试集**（纯代码、纯语言识别、纯法律、纯数学），每次只有一个任务的数据
- Router 对数据集进行分析，输出该分布下的全局合并权重 $\boldsymbol{\alpha}$
- 使用合并后的 backbone + **对应任务的正确分类头**（此实验不考虑分类头选择问题，直接使用 ground truth 分类头）
- 记录分类准确率并与微调基线对比

> **为什么使用 ground truth 分类头？** 因为实验一的目的是**单独验证合并系数 $\alpha$ 的质量**，排除分类头选择可能带来的干扰。将两个自动化问题解耦评估。

#### 结果展示（表格）

**表 4.X：单任务测试集上的合并效果对比**

| 任务     | $\alpha_{\text{code}}$ | $\alpha_{\text{langid}}$ | $\alpha_{\text{law}}$ | $\alpha_{\text{math}}$ | 合并 ACC | 基线 ACC | Gap  | 归一化 ACC |
| -------- | ---------------------- | ------------------------ | --------------------- | ---------------------- | -------- | -------- | ---- | ---------- |
| code     | —                      | —                        | —                     | —                      | —%       | 69.50%   | —    | —%         |
| langid   | —                      | —                        | —                     | —                      | —%       | 91.73%   | —    | —%         |
| law      | —                      | —                        | —                     | —                      | —%       | 70.57%   | —    | —%         |
| math     | —                      | —                        | —                     | —                      | —%       | 95.85%   | —    | —%         |
| **平均** | —                      | —                        | —                     | —                      | —%       | —        | —    | —%         |

从 `eval_results_1/` 和 `eval_results_2/` 以及 `checkpoints/20260227_191859.../evaluation_results.json` 中提取实际数据填入。

#### 分析要点（建议写 3-4 段）

**第一段：总体性能**

- 合并模型的平均归一化 ACC 是多少？与微调基线的平均差距
- 强调：Router 只有极少参数（两个小 MLP head），却能让合并后的单一模型在多个任务上接近各自微调模型的性能

**第二段：α 分布分析**

- 分析 Router 输出的 $\alpha$ 是否符合直觉：纯单任务输入时，对应任务的 $\alpha_k$ 是否最大？
- 理想情况下应接近 one-hot：如纯数学输入时 $\alpha_{\text{math}} \approx 1$，其余 $\approx 0$
- 如果偏差较大，分析原因（如某些任务的 task vector 之间存在正迁移，其他任务的 $\alpha$ 不为零反而有助于性能）

**第三段：各任务差异分析**

- 哪些任务的归一化 ACC 最高/最低？原因可能是什么？
  - 类别数差异（code=707 类，分类难度远大于 langid=6 类）
  - task vector 的质量差异（稀疏微调的 mask 覆盖率不同）
  - 任务间知识迁移的程度不同

**第四段（可选）：与对比方法的比较**

- Uniform Merge（$\alpha_k = 0.25$）的性能如何？远低于 Router 方法说明自适应系数的必要性
- 如果有 Grid Search 数据，说明 Router 自动找到的 $\alpha$ 接近最优解

---

### 4.3.3 实验二：混合数据集上的任务识别性能评估（建议 1.5-2 页）

#### 实验目的

> 验证 Router 的 Task Classifier 自动选择分类头的能力。在混合数据集场景中，Router 需要正确识别每条样本所属的任务，才能为其匹配正确的分类头。

#### 实验方法

对应 `guide.md` 中的**评估二的任务识别部分**：

- 构造四个不同混合比例的测试数据集（Mix-A 到 Mix-D）
- Router 对每条样本预测其任务归属 $\hat{t}_i = \arg\max_k \beta_k^{(i)}$
- 将预测的任务归属与真实标签对比，计算任务识别准确率和各任务召回率
- **使用 Router 预测的分类头**（而非 ground truth），计算最终分类准确率

#### 测试数据集构成

**表 4.X：混合测试数据集配置**

| 数据集 | code | langid | law  | math | 总数 | 设计意图                      |
| ------ | ---- | ------ | ---- | ---- | ---- | ----------------------------- |
| Mix-A  | 1000 | 1000   | 1000 | 1000 | 4000 | 均匀分布，测试基础能力        |
| Mix-B  | 2000 | 400    | 1200 | 400  | 4000 | 代码为主（50%），测试偏斜分布 |
| Mix-C  | 400  | 400    | 400  | 2800 | 4000 | 数学为主（70%），测试极端偏斜 |
| Mix-D  | 200  | 2400   | 200  | 1200 | 4000 | 语言识别为主（60%）           |

#### 结果展示

**表 4.X：混合数据集上的任务识别准确率**

| 数据集 | 整体 Task ACC | code Recall | langid Recall | law Recall | math Recall |
| ------ | ------------- | ----------- | ------------- | ---------- | ----------- |
| Mix-A  | —%            | —%          | —%            | —%         | —%          |
| Mix-B  | —%            | —%          | —%            | —%         | —%          |
| Mix-C  | —%            | —%          | —%            | —%         | —%          |
| Mix-D  | —%            | —%          | —%            | —%         | —%          |

**表 4.X：使用 Router 预测分类头后的最终分类 ACC**（与使用 ground truth 分类头的对比）

| 数据集 | GT Head ACC | Router Head ACC | 因分类头误选导致的 ACC 损失 |
| ------ | ----------- | --------------- | --------------------------- |
| Mix-A  | —%          | —%              | —%                          |
| Mix-B  | —%          | —%              | —%                          |
| Mix-C  | —%          | —%              | —%                          |
| Mix-D  | —%          | —%              | —%                          |

#### 分析要点（建议写 3-4 段）

**第一段：任务识别的整体效果**

- 四个混合比例下的平均 Task Classification ACC
- 强调 Router 仅使用冻结的 word embedding + 一个轻量级 MLP 就能区分四种任务类型
- 详细解析数据，并说明其性能强大

---

### 4.3.4 实验三：不同数据分布下的路由泛化性评估（建议 1.5-2 页）

#### 实验目的

> 验证 Router 在不同数据分布下输出合并系数 $\boldsymbol{\alpha}$ 的合理性和泛化性。核心问题：Router 是否学到了"根据数据分布自适应调整合并权重"的通用策略，而非过拟合到训练时的某种特定分布？

#### 实验方法

对应 guide.md 中的**评估二的 $\alpha$ 分布部分**，但独立成章进行更深入的分析：

- 使用与实验二相同的四个混合数据集（Mix-A 到 Mix-D）
- 重点关注 Router 输出的 $\boldsymbol{\alpha}$ 值
- 分析 $\boldsymbol{\alpha}$ 与数据集中各任务**实际占比**之间的相关性
- 额外补充若干**极端分布**和**渐变分布**测试

#### 结果展示

**表 4.X：不同混合比例下 Router 输出的合并系数**

| 数据集    | 实际占比 (code/langid/law/math) | $\alpha_{\text{code}}$ | $\alpha_{\text{langid}}$ | $\alpha_{\text{law}}$ | $\alpha_{\text{math}}$ |
| --------- | ------------------------------- | ---------------------- | ------------------------ | --------------------- | ---------------------- |
| 纯 code   | 100/0/0/0                       | —                      | —                        | —                     | —                      |
| 纯 langid | 0/100/0/0                       | —                      | —                        | —                     | —                      |
| 纯 law    | 0/0/100/0                       | —                      | —                        | —                     | —                      |
| 纯 math   | 0/0/0/100                       | —                      | —                        | —                     | —                      |
| Mix-A     | 25/25/25/25                     | —                      | —                        | —                     | —                      |
| Mix-B     | 50/10/30/10                     | —                      | —                        | —                     | —                      |
| Mix-C     | 10/10/10/70                     | —                      | —                        | —                     | —                      |
| Mix-D     | 5/60/5/30                       | —                      | —                        | —                     | —                      |

> 为了更清晰展示 Router 的自适应能力，设计一组**渐变分布实验**：固定其他三个任务样本数不变，逐步增加某一个任务的样本比例，观察 $\alpha$ 的变化趋势。

**表 4.X：数学任务占比渐变实验**

| 实验编号 | math 占比 | 其余各占比  | $\alpha_{\text{code}}$ | $\alpha_{\text{langid}}$ | $\alpha_{\text{law}}$ | $\alpha_{\text{math}}$ | 合并 ACC |
| -------- | --------- | ----------- | ---------------------- | ------------------------ | --------------------- | ---------------------- | -------- |
| G-1      | 10%       | 30%/30%/30% | —                      | —                        | —                     | —                      | —        |
| G-2      | 25%       | 25%/25%/25% | —                      | —                        | —                     | —                      | —        |
| G-3      | 40%       | 20%/20%/20% | —                      | —                        | —                     | —                      | —        |
| G-4      | 55%       | 15%/15%/15% | —                      | —                        | —                     | —                      | —        |
| G-5      | 70%       | 10%/10%/10% | —                      | —                        | —                     | —                      | —        |
| G-6      | 85%       | 5%/5%/5%    | —                      | —                        | —                     | —                      | —        |
| G-7      | 100%      | 0%/0%/0%    | —                      | —                        | —                     | —                      | —        |

#### 分析要点（建议写 3-4 段）

**第一段：算法的泛化性**

- 在多个混合数据集中都取得了比较好的效果，充分说明了其鲁棒性。

**第二段：$\alpha$ 与数据分布的相关性**

- 计算 $\alpha_k$ 与对应任务实际占比之间的 **Pearson/Spearman 相关系数**
- 理想情况下，占比越高的任务，对应的 $\alpha$ 越大
- 但注意：由于 sigmoid 激活，$\alpha$ 的范围是 $(0, 1)$，且不要求和为 1，所以不期望 $\alpha$ 线性正比于占比

---

## 4.4 本章小结（建议 0.5-1 页）

**撰写要点**：

1. 总结本章提出的方法：基于轻量级 Router 的自动权重集成方案
2. 强调三个核心贡献：
   - Task Vector 作为模型知识的可组合表示
   - Router 网络实现数据驱动的自适应合并
   - 多目标损失函数保证合并质量
3. 实验结论：相比手动调参和均匀合并，本方法在 XX 指标上提升了 XX%

