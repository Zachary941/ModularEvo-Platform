"""
全局配置文件：模型路径、任务定义、超参数等。
所有路径均为绝对路径，方便在不同工作目录下运行。
"""
import os

# ===== 项目根目录 =====
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROUTER_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROUTER_DIR, 'data')

# ===== 基座模型 =====
BASE_MODEL_PATH = os.path.join(PROJECT_ROOT, 'data', 'gpt-neo-125m')
HIDDEN_SIZE = 768  # GPT-Neo 125M

# ===== 任务配置 =====
# 任务名列表（与 Router 的 num_tasks 索引对应）
TASK_NAMES = ['code', 'langid', 'law', 'math']
NUM_TASKS = len(TASK_NAMES)

# 各任务的详细配置
TASK_CONFIGS = {
    'code': {
        'num_classes': 1006,
        'model_path': os.path.join(
            PROJECT_ROOT,
            'fintune/save_model_with_mask_0.25/code/lr5e-05_bs8_e4_p6_all/best_model/pytorch_model.bin'
        ),
        'description': '代码语言分类 (1006种编程语言)',
    },
    'langid': {
        'num_classes': 6,
        'model_path': os.path.join(
            PROJECT_ROOT,
            'fintune/save_model_with_mask_0.25/langid/20250309_142219_lr5e-05_bs16_e4_p6/best_model/pytorch_model.bin'
        ),
        'description': '欧洲语言识别 (6种语言)',
    },
    'law': {
        'num_classes': 13,
        'model_path': os.path.join(
            PROJECT_ROOT,
            'fintune/save_model_with_mask_0.25/law/scotus/lr5e-05_bs4_e4/result/pytorch_model.bin'
        ),
        'description': '法律分类/SCOTUS (13个类别)',
    },
    'math': {
        'num_classes': 25,
        'model_path': os.path.join(
            PROJECT_ROOT,
            'fintune/save_model_with_mask_0.25/mathqa/lr5e-05_bs4_e2/best_model/pytorch_model.bin'
        ),
        'description': '数学QA分类 (25个topic)',
    },
}

# ===== Task Vector 和分类头存储路径 =====
TASK_VECTORS_DIR = os.path.join(DATA_DIR, 'task_vectors')
HEADS_DIR = os.path.join(DATA_DIR, 'heads')

# ===== 任务名到索引的映射 =====
TASK_NAME_TO_IDX = {name: idx for idx, name in enumerate(TASK_NAMES)}
IDX_TO_TASK_NAME = {idx: name for idx, name in enumerate(TASK_NAMES)}
