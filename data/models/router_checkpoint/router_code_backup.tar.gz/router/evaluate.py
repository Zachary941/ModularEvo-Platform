"""
步骤6：评估脚本 (Evaluation)

三大评估维度：
6.1 评估一：合并效果评估（单任务 ACC）：
    - 依次输入 100% 的单任务测试数据集
    - Router 给出 α，合并模型后计算该任务的分类 ACC
    - 与微调基线对比（隔离测试 Merge Head 质量）

6.2 评估二：任务识别性能评估（混合数据集）：
    - 构造不同混合比例的数据集 (Mix-A/B/C/D)
    - 评估 Task Classification ACC、Per-task Recall、α 值
    - 隔离测试 Task Classifier 质量

6.3 评估三：端到端系统评估（混合数据集）：
    - 模拟真实部署：混合数据集 → dataset-level α → 唯一主干 → Task Classifier 自动选头
    - 计算各任务下游分类 ACC，验证完整系统的端到端性能

6.4 输出格式化的评估报告表格
"""

import os
import sys
import json
import logging
import argparse
import numpy as np
import torch
import torch.nn.functional as F
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import (
    TASK_NAMES, TASK_CONFIGS, TASK_NAME_TO_IDX, IDX_TO_TASK_NAME,
    NUM_TASKS, HIDDEN_SIZE, ROUTER_DIR
)
from task_vectors import load_task_vectors_and_heads
from router import create_router
from merge import compute_merged_params, merged_forward
from data import (
    load_task_datasets, MixedBatchSampler,
    create_single_task_dataloader,
)
from train import load_checkpoint

# ---------- Logging ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

# ===== 基线 ACC（微调模型在各任务测试集上的 ACC）=====
BASELINE_ACC = {
    'code':   0.8390,
    'langid': 0.9173,
    'law':    0.7057,
    'math':   0.9585,
}

# ===== 混合数据集配置（各任务绝对样本数）=====
# 各任务测试集大小参考: code~23703, langid~3000, law~1400, math~10000
MIX_CONFIGS = {
    'Mix-A': {'code': 1000, 'langid': 1000, 'law': 1000, 'math': 1000},  # 均匀分布
    'Mix-B': {'code': 2000, 'langid': 400, 'law': 1200, 'math': 400},    # 代码为主
    'Mix-C': {'code': 400, 'langid': 400, 'law': 400, 'math': 2800},     # 数学为主
    'Mix-D': {'code': 200, 'langid': 2400, 'law': 200, 'math': 1200},    # 语言识别为主
}

# 端到端评估专用配置：包含全量混合 + 标准混合
# Mix-Full 使用各任务全部测试数据
E2E_MIX_CONFIGS = {
    'Mix-Full': {'code': 23703, 'langid': 3000, 'law': 1400, 'math': 10000},  # 全量测试数据
    **MIX_CONFIGS,
}


# ===== 评估一：单任务 ACC =====
@torch.no_grad()
def evaluate_single_task(router, base_model, base_params, task_vectors, heads,
                         device, batch_size=32, max_samples=None):
    """
    评估一：合并效果评估（单任务 ACC）。

    对每个任务，使用 100% 单任务测试数据经过 Router 得到 α，合并模型后计算 ACC。

    Args:
        router: 训练好的 Router
        base_model: GPTNeoForCausalLM
        base_params: 基座模型参数
        task_vectors: Task Vectors
        heads: 分类头
        device: 计算设备
        batch_size: 评估 batch 大小
        max_samples: 每任务最大样本数 (None=全部)

    Returns:
        results: dict, key=task_name, value=dict(acc, alphas, num_samples)
    """
    router.eval()
    results = {}

    for task_name in TASK_NAMES:
        logger.info(f"\n  评估单任务 [{task_name}]...")

        # 加载测试数据
        dataloader, label_map = create_single_task_dataloader(
            task_name, split='test', batch_size=batch_size, max_samples=max_samples
        )

        all_alphas = []
        correct = 0
        total = 0

        for batch in dataloader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            # TaskDataset 返回 'label' (单数), MixedBatchSampler 返回 'labels' (复数)
            labels = batch.get('labels', batch.get('label')).to(device)

            # Router forward → alphas
            alphas, task_logits, _ = router(input_ids, attention_mask)
            all_alphas.append(alphas.cpu())

            # 合并模型
            merged_params = compute_merged_params(base_params, task_vectors, alphas)

            # 前向推理（所有样本属于同一个任务）
            task_ids = [task_name] * len(input_ids)
            all_logits, all_indices = merged_forward(
                base_model, merged_params, heads,
                input_ids, attention_mask, task_ids
            )

            if task_name in all_logits:
                preds = all_logits[task_name].argmax(dim=-1)
                idx = all_indices[task_name]
                sub_labels = labels[idx]
                correct += (preds == sub_labels).sum().item()
                total += len(sub_labels)

        # 汇总
        avg_alphas = torch.stack(all_alphas).mean(dim=0).numpy()
        acc = correct / max(total, 1)
        baseline = BASELINE_ACC.get(task_name, 0.0)
        normalized_acc = acc / baseline if baseline > 0 else 0.0

        results[task_name] = {
            'acc': acc,
            'normalized_acc': normalized_acc,
            'alphas': avg_alphas.tolist(),
            'num_samples': total,
        }
        logger.info(f"    {task_name}: ACC={acc:.4f} ({correct}/{total}), "
                     f"归一化={normalized_acc:.2%}, "
                     f"α={np.array2string(avg_alphas, precision=4, separator=', ')}")

    return results


# ===== 评估二：混合数据集任务识别 =====
@torch.no_grad()
def evaluate_mixed_task_classification(router, base_model, base_params,
                                       task_vectors, heads, device,
                                       batch_size=32,
                                       max_samples_per_task=None,
                                       task_datasets=None):
    """
    评估二：任务识别性能评估（混合数据集）。

    对每个 Mix 配置，按 MIX_CONFIGS 中指定的各任务绝对样本数构造混合数据集，测量：
    - Task Classification ACC
    - Per-task Recall
    - Router 输出的 α 值

    Args:
        router: 训练好的 Router
        base_model: GPTNeoForCausalLM
        base_params: 基座模型参数
        task_vectors: Task Vectors
        heads: 分类头
        device: 计算设备
        batch_size: 评估 batch 大小
        max_samples_per_task: 每任务加载的最大样本数

    Returns:
        results: dict, key=mix_name, value=dict(task_acc, per_task_recall, alphas)
    """
    router.eval()
    results = {}

    # 加载测试数据（如果未提供）
    if task_datasets is None:
        logger.info("\n  加载混合评估测试数据...")
        task_datasets, _ = load_task_datasets(
            split='test', max_samples_per_task=max_samples_per_task
        )

    for mix_name, task_counts in MIX_CONFIGS.items():
        total_mix = sum(task_counts.values())
        logger.info(f"\n  评估混合数据集 [{mix_name}] (总样本数={total_mix}): "
                     f"code={task_counts['code']} / langid={task_counts['langid']} / "
                     f"law={task_counts['law']} / math={task_counts['math']}")

        # 按固定样本数构造混合 batch
        mix_batches = _create_fixed_count_batches(
            task_datasets, task_counts, batch_size
        )

        all_alphas = []
        task_cls_correct = 0
        task_cls_total = 0
        per_task_correct = defaultdict(int)
        per_task_total = defaultdict(int)

        for batch in mix_batches:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            task_ids = batch['task_ids']

            # Router forward
            alphas, task_logits, _ = router(input_ids, attention_mask)
            all_alphas.append(alphas.cpu())

            # Task Classification ACC
            task_labels = torch.tensor(
                [TASK_NAME_TO_IDX[t] for t in task_ids], device=device
            )
            task_preds = task_logits.argmax(dim=-1)
            task_cls_correct += (task_preds == task_labels).sum().item()
            task_cls_total += len(task_labels)

            # Per-task recall
            for task_name in TASK_NAMES:
                mask = (task_labels == TASK_NAME_TO_IDX[task_name])
                if mask.sum() > 0:
                    per_task_total[task_name] += mask.sum().item()
                    per_task_correct[task_name] += (
                        (task_preds[mask] == task_labels[mask]).sum().item()
                    )

        # 汇总
        avg_alphas = torch.stack(all_alphas).mean(dim=0).numpy()
        task_acc = task_cls_correct / max(task_cls_total, 1)

        per_task_recall = {}
        for task_name in TASK_NAMES:
            if per_task_total[task_name] > 0:
                per_task_recall[task_name] = (
                    per_task_correct[task_name] / per_task_total[task_name]
                )
            else:
                per_task_recall[task_name] = 0.0

        results[mix_name] = {
            'task_acc': task_acc,
            'per_task_recall': per_task_recall,
            'alphas': avg_alphas.tolist(),
            'num_samples': task_cls_total,
        }

        logger.info(f"    Task ACC: {task_acc:.4f}")
        logger.info(f"    Per-task Recall: {', '.join(f'{k}={v:.4f}' for k, v in per_task_recall.items())}")
        logger.info(f"    α: {np.array2string(avg_alphas, precision=4, separator=', ')}")

    return results


def _create_fixed_count_batches(task_datasets, total_task_counts, batch_size):
    """
    按固定样本数从各任务数据集中采样，构造混合 batch。
    每个 batch 内维持与总体一致的任务比例。

    Args:
        task_datasets: Dict[str, TaskDataset]
        total_task_counts: Dict[str, int] 各任务的目标总样本数
        batch_size: batch 大小

    Returns:
        list of batch dicts: {input_ids, attention_mask, labels, task_ids}
    """
    import torch

    total = sum(total_task_counts.values())
    if total == 0:
        return []

    num_batches = max(1, total // batch_size)

    # 从总数计算比例，再换算每个 batch 中各任务的样本数
    ratios = {t: c / total for t, c in total_task_counts.items()}
    per_batch_counts = {}
    remaining = batch_size
    for i, task_name in enumerate(TASK_NAMES):
        if i == len(TASK_NAMES) - 1:
            per_batch_counts[task_name] = remaining
        else:
            if total_task_counts.get(task_name, 0) == 0:
                per_batch_counts[task_name] = 0
            else:
                count = max(1, int(round(batch_size * ratios[task_name])))
                count = min(count, remaining)
                per_batch_counts[task_name] = count
            remaining -= per_batch_counts[task_name]

    # 各任务的采样索引（循环使用）
    task_indices = {}
    for task_name in TASK_NAMES:
        ds = task_datasets[task_name]
        n = len(ds)
        shuffled = np.random.permutation(n).tolist()
        task_indices[task_name] = {
            'indices': shuffled,
            'pos': 0,
            'size': n,
        }

    batches = []
    for _ in range(num_batches):
        all_input_ids = []
        all_attention_mask = []
        all_labels = []
        all_task_ids = []

        for task_name in TASK_NAMES:
            count = per_batch_counts[task_name]
            if count == 0:
                continue
            ds = task_datasets[task_name]
            info = task_indices[task_name]

            for _ in range(count):
                idx = info['indices'][info['pos'] % info['size']]
                info['pos'] += 1

                sample = ds[idx]
                all_input_ids.append(sample['input_ids'])
                all_attention_mask.append(sample['attention_mask'])
                all_labels.append(sample['label'])
                all_task_ids.append(task_name)

        # Stack tensors
        batch = {
            'input_ids': torch.stack(all_input_ids),
            'attention_mask': torch.stack(all_attention_mask),
            'labels': torch.tensor(all_labels, dtype=torch.long),
            'task_ids': all_task_ids,
        }
        batches.append(batch)

    return batches


# ===== 评估三：端到端系统评估 =====
@torch.no_grad()
def evaluate_end_to_end(router, base_model, base_params, task_vectors, heads,
                       device, batch_size=32, max_samples_per_task=None,
                       task_datasets=None):
    """
    评估三：端到端系统评估（模拟真实部署）。

    模拟真实客户使用场景：
    1. 混合数据集输入 → Router 为每个 batch 生成 α
    2. 每个 batch 使用自己的 α 合并主干（与评估一一致）
    3. Task Classifier 自动选头（不使用 ground truth）
    4. 计算各任务的下游分类 ACC

    与评估一的区别：评估一用 ground truth 选头，隔离测试 Merge Head；
    评估三用 Task Classifier 自动选头，测试完整系统。

    Args:
        router: 训练好的 Router
        base_model: GPTNeoForCausalLM
        base_params: 基座模型参数
        task_vectors: Task Vectors
        heads: 分类头
        device: 计算设备
        batch_size: 评估 batch 大小
        max_samples_per_task: 每任务加载的最大样本数
        task_datasets: 预加载的测试数据集（可选，避免重复加载）

    Returns:
        results: dict, key=mix_name, value=dict(per_task_acc, per_task_norm_acc, alphas, ...)
    """
    router.eval()
    results = {}

    # 加载测试数据（如果未提供）
    if task_datasets is None:
        logger.info("\n  加载端到端评估测试数据...")
        task_datasets, _ = load_task_datasets(
            split='test', max_samples_per_task=max_samples_per_task
        )

    # 使用端到端专用配置（含 Mix-Full）
    e2e_configs = E2E_MIX_CONFIGS

    for mix_name, task_counts in e2e_configs.items():
        total_mix = sum(task_counts.values())
        logger.info(f"\n  端到端评估 [{mix_name}] (总样本数={total_mix}): "
                     f"code={task_counts['code']} / langid={task_counts['langid']} / "
                     f"law={task_counts['law']} / math={task_counts['math']}")

        mix_batches = _create_fixed_count_batches(
            task_datasets, task_counts, batch_size
        )

        # ===== Phase 1: 收集所有样本的 per_sample_alphas 和 task_preds =====
        all_input_ids = []
        all_attention_mask = []
        all_labels = []
        all_gt_task_ids = []
        all_pred_task_ids = []
        all_per_sample_alphas = []

        for batch in mix_batches:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)

            alphas, task_logits, per_sample_alphas = router(input_ids, attention_mask)
            task_preds = task_logits.argmax(dim=-1).cpu()

            all_input_ids.append(batch['input_ids'])
            all_attention_mask.append(batch['attention_mask'])
            all_labels.append(batch['labels'])
            all_gt_task_ids.extend(batch['task_ids'])
            all_pred_task_ids.extend([IDX_TO_TASK_NAME[p.item()] for p in task_preds])
            all_per_sample_alphas.append(per_sample_alphas.cpu())

        # 拼接所有样本
        all_input_ids = torch.cat(all_input_ids, dim=0)
        all_attention_mask = torch.cat(all_attention_mask, dim=0)
        all_labels = torch.cat(all_labels, dim=0)
        all_per_sample_alphas = torch.cat(all_per_sample_alphas, dim=0)  # [N, num_tasks]
        N = len(all_gt_task_ids)

        # ===== Phase 2: 按预测任务分组 → 每组独立合并 backbone → 独立推理 =====
        per_task_correct = defaultdict(int)
        per_task_total = defaultdict(int)
        per_task_wrong_head = defaultdict(int)
        per_group_alpha = {}

        pred_task_set = set(all_pred_task_ids)
        for pred_task in pred_task_set:
            # 找到被预测为此任务的所有样本索引
            group_indices = [i for i in range(N) if all_pred_task_ids[i] == pred_task]
            if not group_indices:
                continue

            idx = torch.tensor(group_indices)
            group_input_ids = all_input_ids[idx].to(device)
            group_attention_mask = all_attention_mask[idx].to(device)
            group_labels = all_labels[idx].to(device)
            group_alphas = all_per_sample_alphas[idx]  # [group_size, num_tasks]

            # 组内 α 均值 → 该组的 backbone（与评估一完全一致）
            group_alpha = group_alphas.mean(dim=0).to(device)  # [num_tasks]
            per_group_alpha[pred_task] = group_alpha.cpu()

            logger.info(f"    组[{pred_task}] (n={len(group_indices)}): α="
                         f"{np.array2string(group_alpha.cpu().numpy(), precision=4, separator=', ')}")

            # 合并该组专属的 backbone
            merged_params = compute_merged_params(base_params, task_vectors, group_alpha)

            # 分 batch 推理（避免 OOM）
            for start in range(0, len(group_indices), batch_size):
                end = min(start + batch_size, len(group_indices))
                b_input_ids = group_input_ids[start:end]
                b_attention_mask = group_attention_mask[start:end]
                b_labels = group_labels[start:end]
                b_global_indices = group_indices[start:end]

                # 所有样本都用 pred_task 对应的头
                b_task_ids = [pred_task] * (end - start)
                all_logits, all_indices = merged_forward(
                    base_model, merged_params, heads,
                    b_input_ids, b_attention_mask, b_task_ids
                )

                if pred_task in all_logits:
                    logits = all_logits[pred_task]
                    preds = logits.argmax(dim=-1)
                    for j in range(end - start):
                        global_idx = b_global_indices[j]
                        gt_task = all_gt_task_ids[global_idx]
                        per_task_total[gt_task] += 1

                        if pred_task != gt_task:
                            per_task_wrong_head[gt_task] += 1
                            continue

                        if preds[j].item() == b_labels[j].item():
                            per_task_correct[gt_task] += 1

        # 汇总
        # 报告用的平均 α：各组 α 的等权平均
        if per_group_alpha:
            avg_alpha = torch.stack(list(per_group_alpha.values())).mean(dim=0)
        else:
            avg_alpha = torch.zeros(len(TASK_NAMES))
        logger.info(f"    各组平均 α: "
                     f"{np.array2string(avg_alpha.numpy(), precision=4, separator=', ')}")

        per_task_acc = {}
        per_task_norm_acc = {}
        for task_name in TASK_NAMES:
            total = per_task_total.get(task_name, 0)
            correct = per_task_correct.get(task_name, 0)
            wrong_head = per_task_wrong_head.get(task_name, 0)
            acc = correct / max(total, 1)
            baseline = BASELINE_ACC.get(task_name, 0.0)
            norm = acc / baseline if baseline > 0 else 0.0
            per_task_acc[task_name] = acc
            per_task_norm_acc[task_name] = norm
            logger.info(f"    {task_name}: ACC={acc:.4f} ({correct}/{total}), "
                         f"归一化={norm:.2%}, "
                         f"错头={wrong_head}/{total} ({wrong_head/max(total,1):.2%})")

        avg_norm = sum(per_task_norm_acc.values()) / len(per_task_norm_acc) if per_task_norm_acc else 0.0
        logger.info(f"    平均归一化 ACC: {avg_norm:.2%}")

        results[mix_name] = {
            'per_task_acc': per_task_acc,
            'per_task_norm_acc': per_task_norm_acc,
            'per_task_wrong_head': dict(per_task_wrong_head),
            'per_task_total': dict(per_task_total),
            'alphas': avg_alpha.numpy().tolist(),
            'avg_norm_acc': avg_norm,
        }

    return results


# ===== 格式化输出报告 =====
def format_evaluation_report(single_task_results, mixed_results, end_to_end_results=None):
    """
    按 guide.md Section 6.3 的格式输出评估报告。

    Args:
        single_task_results: evaluate_single_task 的返回值
        mixed_results: evaluate_mixed_task_classification 的返回值
        end_to_end_results: evaluate_end_to_end 的返回值（可选）

    Returns:
        report: str 格式化的评估报告
    """
    lines = []
    lines.append("")
    lines.append("=" * 70)
    lines.append("  评估报告")
    lines.append("=" * 70)

    # --- 评估一：单任务 ACC ---
    if single_task_results:
        lines.append("")
        lines.append("--- 评估一：合并效果评估（单任务 ACC）---")
        lines.append(
            f"| {'任务':^8s} | {'α_code':^8s} | {'α_langid':^8s} | {'α_law':^8s} "
            f"| {'α_math':^8s} | {'ACC':^8s} | {'基线 ACC':^8s} | {'差距':^8s} | {'归一化':^8s} |"
        )
        lines.append("|" + "----------|" * 8)

        acc_list = []
        norm_list = []
        for task_name in TASK_NAMES:
            r = single_task_results[task_name]
            alphas = r['alphas']
            acc = r['acc']
            baseline = BASELINE_ACC[task_name]
            diff = acc - baseline
            diff_str = f"{diff:+.2%}"
            normalized = acc / baseline * 100 if baseline > 0 else 0.0
            norm_str = f"{normalized:.2f}%"
            acc_list.append(acc)
            norm_list.append(normalized)

            lines.append(
                f"| {task_name:^8s} "
                f"| {alphas[0]:^8.4f} | {alphas[1]:^8.4f} | {alphas[2]:^8.4f} "
                f"| {alphas[3]:^8.4f} | {acc:^8.2%} | {baseline:^8.2%} | {diff_str:^8s} | {norm_str:^8s} |"
            )

        # 平均行
        avg_acc = sum(acc_list) / len(acc_list) if acc_list else 0.0
        avg_norm = sum(norm_list) / len(norm_list) if norm_list else 0.0
        lines.append(
            f"| {'平均':^8s} "
            f"| {'—':^8s} | {'—':^8s} | {'—':^8s} "
            f"| {'—':^8s} | {avg_acc:^8.2%} | {'—':^8s} | {'—':^8s} | {f'{avg_norm:.2f}%':^8s} |"
        )

    # --- 评估二：混合数据集 ---
    if mixed_results:
        lines.append("")
        lines.append("--- 评估二：任务识别性能评估（混合数据集）---")
        lines.append(
            f"| {'数据集':^8s} | {'数量(码/语/法/数)':^20s} | {'Task ACC':^10s} "
            f"| {'α_code':^8s} | {'α_langid':^8s} | {'α_law':^8s} | {'α_math':^8s} |"
        )
        lines.append("|" + "----------|" * 2 + "----------------------|" + "----------|" * 4)

        for mix_name, mix_counts in MIX_CONFIGS.items():
            r = mixed_results[mix_name]
            alphas = r['alphas']
            count_str = "/".join(
                f"{mix_counts[t]}" for t in TASK_NAMES
            )
            lines.append(
                f"| {mix_name:^8s} | {count_str:^20s} | {r['task_acc']:^10.2%} "
                f"| {alphas[0]:^8.4f} | {alphas[1]:^8.4f} | {alphas[2]:^8.4f} "
                f"| {alphas[3]:^8.4f} |"
            )

        # Per-task recall 详情
        lines.append("")
        lines.append("--- Per-task Recall (各任务召回率) ---")
        lines.append(
            f"| {'数据集':^8s} | {'code':^8s} | {'langid':^8s} | {'law':^8s} | {'math':^8s} |"
        )
        lines.append("|" + "----------|" * 5)

        for mix_name in MIX_CONFIGS:
            r = mixed_results[mix_name]
            recall = r['per_task_recall']
            lines.append(
                f"| {mix_name:^8s} "
                f"| {recall.get('code', 0):^8.2%} "
                f"| {recall.get('langid', 0):^8.2%} "
                f"| {recall.get('law', 0):^8.2%} "
                f"| {recall.get('math', 0):^8.2%} |"
            )

    # --- 评估三：端到端系统评估 ---
    if end_to_end_results:
        lines.append("")
        lines.append("--- 评估三：端到端系统评估（混合数据集 → 自动选头 → 下游 ACC）---")
        lines.append(
            f"| {'数据集':^8s} | {'α_code':^8s} | {'α_langid':^8s} | {'α_law':^8s} "
            f"| {'α_math':^8s} | {'code':^8s} | {'langid':^8s} | {'law':^8s} "
            f"| {'math':^8s} | {'平均归一化':^10s} |"
        )
        lines.append("|" + "----------| " * 9 + "------------| ")

        for mix_name in end_to_end_results:
            r = end_to_end_results[mix_name]
            alphas = r['alphas']
            pa = r['per_task_acc']
            avg_norm = r['avg_norm_acc'] * 100
            lines.append(
                f"| {mix_name:^8s} "
                f"| {alphas[0]:^8.4f} | {alphas[1]:^8.4f} | {alphas[2]:^8.4f} "
                f"| {alphas[3]:^8.4f} | {pa.get('code',0):^8.2%} | {pa.get('langid',0):^8.2%} "
                f"| {pa.get('law',0):^8.2%} | {pa.get('math',0):^8.2%} "
                f"| {f'{avg_norm:.2f}%':^10s} |"
            )

        # 错头率详情
        lines.append("")
        lines.append("--- 评估三：错头率（Task Classifier 误判导致）---")
        lines.append(
            f"| {'数据集':^8s} | {'code':^8s} | {'langid':^8s} | {'law':^8s} | {'math':^8s} |"
        )
        lines.append("|" + "----------| " * 4 + "----------| ")

        for mix_name in end_to_end_results:
            r = end_to_end_results[mix_name]
            wh = r.get('per_task_wrong_head', {})
            pt = r.get('per_task_total', {})
            vals = []
            for tn in TASK_NAMES:
                w = wh.get(tn, 0)
                t = pt.get(tn, 1)
                vals.append(f"{w/max(t,1):.2%}")
            lines.append(
                f"| {mix_name:^8s} "
                f"| {vals[0]:^8s} | {vals[1]:^8s} | {vals[2]:^8s} | {vals[3]:^8s} |"
            )

    lines.append("")
    lines.append("=" * 70)

    return "\n".join(lines)


# ===== 完整评估流程 =====
def evaluate(checkpoint_path=None, batch_size=32, max_samples=None,
             save_report=True, force_cpu=False,
             save_dir=None, only_e2e=False):
    """
    完整评估流程：加载 Router → 评估一（单任务 ACC）→ 评估二（任务识别）→ 评估三（端到端）→ 输出报告。

    Args:
        checkpoint_path: Router checkpoint 路径 (None=自动寻找 best_router.pt)
        batch_size: 评估 batch 大小
        max_samples: 每任务最大样本数 (None=全部)
        save_report: 是否保存报告到文件
        force_cpu: 强制使用 CPU（当 GPU 被训练进程占用时）
        save_dir: 评估结果保存目录（None=自动从 checkpoint_path 推断）
        only_e2e: 仅运行评估三（端到端），跳过评估一和评估二

    Returns:
        single_task_results: 单任务评估结果（only_e2e=True 时为 None）
        mixed_results: 混合数据集评估结果（only_e2e=True 时为 None）
        end_to_end_results: 端到端评估结果
    """
    if force_cpu:
        device = torch.device('cpu')
    else:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"设备: {device}")

    # ===== 1. 加载模型组件 =====
    logger.info("\n" + "=" * 60)
    logger.info("加载模型组件...")
    logger.info("=" * 60)

    base_model, base_params, task_vectors, heads = load_task_vectors_and_heads()
    base_model = base_model.to(device)
    for key in base_params:
        base_params[key] = base_params[key].to(device)
    for task_name in task_vectors:
        for key in task_vectors[task_name]:
            task_vectors[task_name][key] = task_vectors[task_name][key].to(device)
    for task_name in heads:
        heads[task_name] = heads[task_name].to(device)

    # ===== 2. 加载 Router =====
    router = create_router(base_model).to(device)

    if checkpoint_path is None:
        checkpoint_path = os.path.join(ROUTER_DIR, 'checkpoints', 'best_router.pt')

    if os.path.exists(checkpoint_path):
        logger.info(f"加载 Router checkpoint: {checkpoint_path}")
        checkpoint = load_checkpoint(checkpoint_path, router)
        if 'metrics' in checkpoint and checkpoint['metrics']:
            logger.info(f"  训练步数: {checkpoint.get('step', '?')}, "
                         f"epoch: {checkpoint.get('epoch', '?')}")
    else:
        logger.warning(f"未找到 checkpoint: {checkpoint_path}")
        logger.warning("将使用随机初始化的 Router 进行评估（结果仅供参考）")

    router.eval()
    logger.info(f"Router 参数: {router.count_trainable_params():,}")

    # 添加 FileHandler，将评估日志写入模型目录下带时间戳的子文件夹
    from datetime import datetime
    eval_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    eval_file_handler = None
    if save_report:
        if save_dir:
            log_dir = save_dir
        elif checkpoint_path and os.path.exists(checkpoint_path):
            model_dir = os.path.dirname(os.path.abspath(checkpoint_path))
            log_dir = os.path.join(model_dir, f'eval_{eval_timestamp}')
        else:
            log_dir = os.path.join(ROUTER_DIR, f'eval_results_{eval_timestamp}')
        os.makedirs(log_dir, exist_ok=True)
        eval_log_path = os.path.join(log_dir, 'eval_log.txt')
        eval_file_handler = logging.FileHandler(eval_log_path, mode='w', encoding='utf-8')
        eval_file_handler.setLevel(logging.INFO)
        eval_file_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
        logging.getLogger().addHandler(eval_file_handler)
        logger.info(f"评估日志: {eval_log_path}")

    single_task_results = None
    mixed_results = None

    if not only_e2e:
        # ===== 3. 评估一：单任务 ACC =====
        logger.info("\n" + "=" * 60)
        logger.info("评估一：合并效果评估（单任务 ACC）")
        logger.info("=" * 60)

        single_task_results = evaluate_single_task(
            router, base_model, base_params, task_vectors, heads,
            device, batch_size=batch_size, max_samples=max_samples
        )

    # ===== 4. 加载混合评估测试数据（评估二和三共享）=====
    logger.info("\n" + "=" * 60)
    logger.info("加载混合评估测试数据...")
    logger.info("=" * 60)

    task_datasets, _ = load_task_datasets(
        split='test', max_samples_per_task=max_samples
    )

    if not only_e2e:
        # ===== 5. 评估二：混合数据集任务识别 =====
        logger.info("\n" + "=" * 60)
        logger.info("评估二：任务识别性能评估（混合数据集）")
        logger.info("=" * 60)

        mixed_results = evaluate_mixed_task_classification(
            router, base_model, base_params, task_vectors, heads,
            device, batch_size=batch_size,
            max_samples_per_task=max_samples,
            task_datasets=task_datasets
        )

    # ===== 6. 评估三：端到端系统评估 =====
    logger.info("\n" + "=" * 60)
    logger.info("评估三：端到端系统评估（混合数据集 → 自动选头 → 下游 ACC）")
    logger.info("=" * 60)

    end_to_end_results = evaluate_end_to_end(
        router, base_model, base_params, task_vectors, heads,
        device, batch_size=batch_size,
        max_samples_per_task=max_samples,
        task_datasets=task_datasets
    )

    # ===== 7. 输出报告 =====
    report = format_evaluation_report(single_task_results, mixed_results, end_to_end_results)
    logger.info(report)

    # 保存结果
    if save_report:
        report_dir = log_dir  # 复用已创建的带时间戳目录

        # JSON 结果
        results = {
            'single_task': single_task_results,
            'mixed_task': mixed_results,
            'end_to_end': end_to_end_results,
            'baseline_acc': BASELINE_ACC,
        }
        json_path = os.path.join(report_dir, 'evaluation_results.json')
        with open(json_path, 'w') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

        txt_path = os.path.join(report_dir, 'evaluation_report.txt')
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write(report)

        logger.info(f"\n结果已保存: {json_path}")
        logger.info(f"报告已保存: {txt_path}")

    # 移除 FileHandler
    if eval_file_handler:
        logging.getLogger().removeHandler(eval_file_handler)
        eval_file_handler.close()

    return single_task_results, mixed_results, end_to_end_results


# ===== CLI 入口 =====
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Evaluate Router')
    parser.add_argument('--checkpoint', type=str, default=None,
                        help='Router checkpoint 路径 (默认: checkpoints/best_router.pt)')
    parser.add_argument('--batch_size', type=int, default=32,
                        help='评估 batch 大小')
    parser.add_argument('--max_samples', type=int, default=None,
                        help='每任务最大样本数 (默认: 全部)')
    parser.add_argument('--no_save', action='store_true',
                        help='不保存报告')
    parser.add_argument('--force_cpu', action='store_true',
                        help='强制使用 CPU（当 GPU 被训练占用时）')
    parser.add_argument('--save_dir', type=str, default=None,
                        help='评估结果保存目录 (默认: 与 checkpoint 同目录)')
    parser.add_argument('--only_e2e', action='store_true',
                        help='仅运行评估三（端到端），跳过评估一和评估二')
    args = parser.parse_args()

    evaluate(
        checkpoint_path=args.checkpoint,
        batch_size=args.batch_size,
        max_samples=args.max_samples,
        save_report=not args.no_save,
        force_cpu=args.force_cpu,
        save_dir=args.save_dir,
        only_e2e=args.only_e2e,
    )
