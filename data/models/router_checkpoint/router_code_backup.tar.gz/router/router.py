"""
步骤2：Router 网络定义（双头架构 + 任务条件化 Merge Head）

Router 是一个轻量级网络，具有两个输出头，共享同一个冻结的 Embedding Encoder：
1. Merge Head（合并权重预测）：接收 [样本特征 + 任务概率] 作为输入，
   对每条样本独立预测 α，然后 Batch 内取均值。
   Task Classifier 的预测概率作为条件输入，使 Merge Head 能感知数据的任务分布，
   从而为不同任务组成的数据集生成差异化的合并权重。
2. Task Classifier Head（任务识别）：对每条样本预测它属于哪个任务

设计目标：
- 用户提供数据集 → Merge Head 根据数据集的任务分布生成合并系数 α
  → 合并出唯一的主干网络（节省显存，无需存储多个模型）
- Task Classifier 在样本级别识别任务 → 为每个样本路由到对应的分类头

设计要点：
- Embedding 层来自 GPTNeoForCausalLM 的 transformer.wte（冻结，不训练）
- Merge Head 输入 = 样本 embedding ⊕ Task Classifier 的 softmax 概率（detach）
- Merge Head 使用 Sigmoid（各 α_i 独立，不互相约束）
- Task Classifier 的概率经 detach 传入 Merge Head，保护 Classifier 不受 merge_loss 干扰
- Task Classifier 不加 Softmax（交给 CrossEntropyLoss 内部处理）
- 只有 merge_head 和 task_classifier 的参数是可训练的
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import HIDDEN_SIZE, NUM_TASKS


class Router(nn.Module):
    """
    动态路由网络：分析输入数据的分布，输出模型合并权重和样本-任务归属。

    架构：Task-Conditioned Merge Head
    1. 所有样本共享冻结 Embedding → Mean Pooling → sample_embeds
    2. Task Classifier 对每条样本预测任务概率 task_probs = softmax(logits)
    3. Merge Head 接收 [sample_embeds ⊕ task_probs]（拼接），输出 per-sample α
    4. Batch 内 per-sample α 取均值 → 最终合并权重

    核心优势：
    - 每条样本的 α 由内容特征 + 任务身份共同决定
    - code 样本的 task_probs ≈ [1,0,0,0] → Merge Head 产生偏重 code 的 α
    - math 样本的 task_probs ≈ [0,0,0,1] → Merge Head 产生偏重 math 的 α
    - Batch 均值自然反映数据集的任务构成比例
    - task_probs 经 detach 传入，merge_loss 不干扰 Classifier 训练
    
    Args:
        embedding_layer: GPTNeoForCausalLM 的 Embedding 层（冻结）
                         即 base_model.transformer.wte
        hidden_size: Embedding 维度（768 for GPT-Neo 125M）
        num_tasks: 任务数量（4：code, langid, law, math）
        merge_hidden_dim: Merge Head 中间层维度
        task_hidden_dim: Task Classifier 中间层维度
        dropout: Dropout 比率
    """
    
    def __init__(
        self,
        embedding_layer: nn.Embedding,
        hidden_size: int = HIDDEN_SIZE,
        num_tasks: int = NUM_TASKS,
        merge_hidden_dim: int = 256,
        task_hidden_dim: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_tasks = num_tasks
        
        # 共享 Encoder：使用冻结的 GPT-Neo Embedding
        self.embedding = embedding_layer
        # 冻结 Embedding 层
        for param in self.embedding.parameters():
            param.requires_grad = False
        
        # Head 1: Merge Weight Predictor（Task-Conditioned, Per-sample → Batch 均值）
        # 输入：per-sample [embedding(768) ⊕ task_probs(4)] [Batch, 772]
        # 输出：per-sample α [Batch, num_tasks]，然后 Batch 均值 → [num_tasks]
        # Task Classifier 的预测概率作为条件输入，使不同任务样本产生差异化的 α
        merge_input_dim = hidden_size + num_tasks  # embedding(768) + task_probs(4)
        self.merge_head = nn.Sequential(
            nn.Linear(merge_input_dim, merge_hidden_dim),
            nn.LayerNorm(merge_hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(merge_hidden_dim, merge_hidden_dim // 2),
            nn.LayerNorm(merge_hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(merge_hidden_dim // 2, merge_hidden_dim // 4),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(merge_hidden_dim // 4, num_tasks),
            nn.Sigmoid()  # 各任务权重独立，不互相约束
        )
        
        # Head 2: Task Classifier（Sample 级别）
        # 输入：每条样本的 Embedding [batch_size, hidden_size]
        # 输出：该样本属于各任务的 logits [batch_size, num_tasks]
        # 3 层 MLP + LayerNorm，增强任务识别能力
        self.task_classifier = nn.Sequential(
            nn.Linear(hidden_size, task_hidden_dim),
            nn.LayerNorm(task_hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(task_hidden_dim, task_hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(task_hidden_dim // 2, num_tasks)
        )
        
        # 初始化可训练参数
        self._init_weights()
    
    def _init_weights(self):
        """Xavier 初始化可训练层的权重"""
        for module in [self.merge_head, self.task_classifier]:
            for layer in module:
                if isinstance(layer, nn.Linear):
                    nn.init.xavier_uniform_(layer.weight)
                    if layer.bias is not None:
                        nn.init.zeros_(layer.bias)
    
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        前向传播。
        
        Args:
            input_ids: [Batch, Seq_Len] 输入 token ids
            attention_mask: [Batch, Seq_Len] attention mask (1=有效, 0=padding)
        
        Returns:
            alphas: [num_tasks] 合并权重（Per-sample α 的 Batch 均值）
            task_logits: [Batch, num_tasks] 每条样本的任务分类 logits
        """
        # 1. 共享 Embedding（冻结，不回传梯度到 Embedding）
        with torch.no_grad():
            embeddings = self.embedding(input_ids)  # [Batch, Seq, Hidden]
        
        # detach 确保梯度不回传到 Embedding
        embeddings = embeddings.detach()
        
        # 2. Per-sample Mean Pooling（考虑 attention_mask，排除 padding）
        mask = attention_mask.unsqueeze(-1).float()              # [Batch, Seq, 1]
        masked_embeds = embeddings * mask                        # [Batch, Seq, Hidden]
        sum_embeds = masked_embeds.sum(dim=1)                    # [Batch, Hidden]
        length = mask.sum(dim=1).clamp(min=1)                    # [Batch, 1] 避免除 0
        sample_embeds = sum_embeds / length                      # [Batch, Hidden]
        
        # 3. Task Classifier：Per-sample → 每条样本的任务 logits
        task_logits = self.task_classifier(sample_embeds)        # [Batch, num_tasks]
        
        # 4. 获取任务概率分布（detach 保护 Classifier 不受 merge_loss 干扰）
        #    task_probs 为 Merge Head 提供强分类信号：
        #    code 样本 → [~1, 0, 0, 0]，math 样本 → [0, 0, 0, ~1]
        task_probs = F.softmax(task_logits, dim=-1).detach()     # [Batch, num_tasks]
        
        # 5. Merge Head：拼接 [embedding + 任务概率] → Per-sample α → Batch 均值
        #    768 维 embedding 保留完整内容信息 + 4 维 task_probs 提供任务条件
        #    不同任务的样本产生不同的 α，Batch 均值自然反映数据集的任务分布
        merge_input = torch.cat([sample_embeds, task_probs], dim=-1)  # [Batch, 772]
        per_sample_alphas = self.merge_head(merge_input)         # [Batch, num_tasks]
        alphas = per_sample_alphas.mean(dim=0)                   # [num_tasks]
        
        return alphas, task_logits, per_sample_alphas
    
    def get_trainable_params(self):
        """返回所有可训练参数（两个 Head）"""
        params = []
        params.extend(self.merge_head.parameters())
        params.extend(self.task_classifier.parameters())
        return params
    
    def count_trainable_params(self) -> int:
        """统计可训练参数数量"""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
    
    def count_total_params(self) -> int:
        """统计总参数数量（含冻结的 Embedding）"""
        return sum(p.numel() for p in self.parameters())


def create_router(base_model) -> Router:
    """
    从已加载的 GPTNeoForCausalLM 创建 Router。
    
    Args:
        base_model: GPTNeoForCausalLM 实例（已 from_pretrained 加载）
    
    Returns:
        Router 实例
    """
    embedding_layer = base_model.transformer.wte
    return Router(
        embedding_layer=embedding_layer,
        hidden_size=HIDDEN_SIZE,
        num_tasks=NUM_TASKS,
    )
